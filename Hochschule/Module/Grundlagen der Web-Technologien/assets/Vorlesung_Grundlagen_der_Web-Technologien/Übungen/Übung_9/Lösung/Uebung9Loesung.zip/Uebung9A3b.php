<?php 
$nutzer = [["Sebastian", 24], ["Marianne", 64], ["Karsten", 14]];
if (!empty($_REQUEST['name'])) {
    setcookie("Besucher", $_REQUEST['name'], time() + 2592000);
}
$nameVorhanden = false;
foreach ($nutzer as $inhalt) {
    if ($inhalt[0] == $_REQUEST['name']) {
        $alter = $inhalt[1];
        $nameVorhanden = true;
    }
}
if ($nameVorhanden) {
    session_start();
    $_SESSION['Name'] = $_REQUEST['name'];
    $_SESSION['Alter'] = $alter;
    print 'Ihre Daten:<br>';
    print 'Name: ' . $_REQUEST['name'] . "<br>";
    print 'Alter: ' . $alter . "<br>";
    print '<form method="post" action="Uebung9A3c.php">';
    print '<input type="submit" value="Bestätigen">';
    print '</form>';
} else {
    print 'Name nicht gespeichert.';
    print '<form method="post" action="Uebung9A3a.php">';
    print '<input type="submit" value="Weiter">';
    print '</form>';
}
?>