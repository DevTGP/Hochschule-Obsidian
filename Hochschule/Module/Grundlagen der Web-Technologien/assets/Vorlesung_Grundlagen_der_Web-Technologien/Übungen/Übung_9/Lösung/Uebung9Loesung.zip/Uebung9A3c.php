<?php 
session_start();
if ($_SESSION['Alter'] < 18) {
    print 'Zugang unter 18 Jahren nicht möglich.';
} else {
    print 'Herzlich willkommen!';
} 
?>