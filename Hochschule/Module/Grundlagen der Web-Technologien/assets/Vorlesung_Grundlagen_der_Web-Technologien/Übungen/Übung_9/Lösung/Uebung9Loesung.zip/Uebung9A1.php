<?php
if (!empty($_REQUEST['zahl'])) {
    print "<p>Ihre Eingabe wurde erfasst und für die Berechnung des neuen Dokuments verwendet.</p>\n";
}
?>
<form method="post" action="Uebung9A1.php">
    Geben Sie eine beliebige Zahl ein:
    <input type="text" name="zahl">
    <br>
    <input type="submit" value="Senden">
</form>
<?php if (!empty($_REQUEST['zahl'])) {
    $handle = fopen("Uebung9A1Zahlen.txt", "r");
    $handle2 = fopen("Uebung9A1Ergebnis.txt", "w");
    $ergebnis = array();
    if ($handle) {
        $i = 0;
        while (!feof($handle)) {
            $inhalt = fgets($handle);
            $ergebnis[$i] = $inhalt;
            $i++;
        }
        if ($_REQUEST['zahl'] != "") {
            $faktor = $_REQUEST['zahl'];
            foreach ($ergebnis as $wert) {
                $wert = intval($wert) * $faktor;
                fputs($handle2, $wert . "\n");
            }
        }
        fclose($handle);
        fclose($handle2);
    } else {
        print "Die Datei konnte nicht geöffnet werden.<br>\n";
    }
} ?>