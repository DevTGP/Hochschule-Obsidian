<?php 
print '<form method="post" action="Uebung9A3b.php">';
print 'Name: <input type="text" name="name"><br><br>';
print '<input type="submit" value="Weiter">';
print '</form>';
?>