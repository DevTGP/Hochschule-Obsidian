<!DOCTYPE html>
<html lang="de"> 
<head>
  <title>Bestellung</title>
</head>
<body>
<h1>Ihre Bestellung</h1>
<?php
$size = $_REQUEST['size'];
$sorte = $_REQUEST['sorte'];
$extra = $_REQUEST['extra'];
$name = $_REQUEST['name'];
$vorname = $_REQUEST['vorname'];
$strasse = $_REQUEST['strasse'];
$plz = $_REQUEST['plz'];
$ort = $_REQUEST['ort'];

//Zuerst prüfen, ob eine Eingabe gemacht wurde
if (($size == "") || ($sorte == "") || ($name == "")) //evtl. Pruefung der uebrigen Felder 
{echo("<h1>Ung&uuml;ltige Eingaben!!!</h1>");}
else
{
echo("<h2>Pizza:</h2>");
echo("<h3>$sorte</h3>");
echo("<h2>Gr&ouml;&szlig;e</h2>");
echo("<h3>$size</h3>");
	if (count($extra) > 0){
	echo("<h2>Zus&auml;tzlicher Belag:</h2>");
	foreach ($extra as $elem) {
		echo "<h3>$elem</h3>";
		}
	}
echo("<h1>F&uuml;r</h1>");
echo("<h2>Name:</h2>");
echo("<h3>$vorname $name</h3>");
echo("<h2>Adresse:</h2>");
echo("<h3>$plz $ort, $strasse</h3>");

//Dateioperationen
$handle = @fopen("Uebung9A2Bestellung.txt", "a") or die("Bestellungsliste kann nicht angelegt oder geoeffnet werden!");

$line =  "--Neue Bestellung--" . "\n" . $sorte . "\n" . $size . "\n"; 

	if (count($extra) > 0){
	foreach ($extra as $elem) {
		$line = $line . $elem . "\n";
		}
}
$line = $line . $name . " " . $vorname . "\n" .  $plz . " " . $ort . " " . $strasse;
$inhalt = fwrite($handle, "$line \n");
fclose($handle);
}
?>
</body>
</html>


