<!DOCTYPE html>
<html lang="de"> 
<head>
  <title>Pizza</title>
  <style> 
label {
    width: 10em;
    display: block;
    float: left;
}
</style>
</head>
<body>
<h1>Pizzabestellung</h1>
<form action="Uebung9A2.php" method="post">
<?php include("Uebung9A2.txt"); ?>
 <fieldset>
 <legend> Adresse</legend>
 <label for="name">Name: <label>
 <input type="text" name="name" id="name"><br>
 <label for="vorname">Vorname: </label>
 <input type="text" name="vorname" id="vorname"><br>
 <label for="strasse">Stra&szlig;e: </label>
 <input type="text" name="strasse" id="strasse"><br>
 <label for="plz">PLZ:</label> 
 <input type="text" name="plz" id="plz"><br>
 <label for="ort">Ort: </label>
 <input type="text" name="ort" id="ort">
 </fieldset>
 <input type="submit" value="send"> 
 <input type="reset">
</p>
</form>
</body>
</html>
