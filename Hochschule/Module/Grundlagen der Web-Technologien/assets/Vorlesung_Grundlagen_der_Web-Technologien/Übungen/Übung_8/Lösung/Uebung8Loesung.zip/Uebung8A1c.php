<?php 
$kundendaten = array();
$kundendaten[0]['Kundennummer'] = 10001;
$kundendaten[0]['Vorname'] = "Heinz";
$kundendaten[0]['Nachname'] = "Mahler";
$kundendaten[1]['Kundennummer'] = 10002;
$kundendaten[1]['Vorname'] = "Eva";
$kundendaten[1]['Nachname'] = "Müller";
$kundendaten[2]['Kundennummer'] = 10003;
$kundendaten[2]['Vorname'] = "Michael";
$kundendaten[2]['Nachname'] = "Mayer";
print "Kundennummer: " . $kundendaten[0]['Kundennummer'] . ", Vorname: " . $kundendaten[0]['Vorname'] . ", Nachname: " . $kundendaten[0]['Nachname'] . "<br>\n";
print "Kundennummer: " . $kundendaten[1]['Kundennummer'] . ", Vorname: " . $kundendaten[1]['Vorname'] . ", Nachname: " . $kundendaten[1]['Nachname'] . "<br>\n";
print "Kundennummer: " . $kundendaten[2]['Kundennummer'] . ", Vorname: " . $kundendaten[2]['Vorname'] . ", Nachname: " . $kundendaten[2]['Nachname'] . "<br>\n";
?>