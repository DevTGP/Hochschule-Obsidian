<?php 
function potenz($wert)
{
    $ergebnis = array();
    for ($i = 0; $i < 10; $i++) {
        $ergebnis[$i] = $wert ** ($i + 1);
    }
    return $ergebnis;
}
$potenzen = potenz(2);

foreach ($potenzen as $ausgabewert) {
    print $ausgabewert . "<br>";
}
?>