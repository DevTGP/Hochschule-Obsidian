<?php 
$zahl1 = 5;
$zahl2 = 7;
print "<p>Variable 1: " . $zahl1 . "</p>\n";
print "<p>Variable 2: " . $zahl2 . "</p>\n";
$ergebnis = $zahl1 * $zahl2;
print "<p>Das Ergebnis aus " . $zahl1 . " * " . $zahl2 . " ist: " . $ergebnis . ".</p>\n";
?> 