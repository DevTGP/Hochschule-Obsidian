<?php 
$zufallszahl = rand(); 
$wurzel = sqrt ($zufallszahl); 
print "Die Wurzel aus ".$zufallszahl." ist ".$wurzel.".<br>\n"; 
?>