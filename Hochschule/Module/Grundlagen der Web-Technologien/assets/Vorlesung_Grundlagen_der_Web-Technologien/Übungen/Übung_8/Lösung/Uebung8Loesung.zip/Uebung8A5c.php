<?php 
class Auto { 
    private $sitzplaetze = 5; 
    public $geschwindigkeit; 
    public $kraftstoffverbrauch; 
    public function setSitzplaetze ($anzahl) { 
        $this->sitzplaetze = $anzahl; } 
    public function getSitzplaetze () { 
        return $this->sitzplaetze; } } 
?>