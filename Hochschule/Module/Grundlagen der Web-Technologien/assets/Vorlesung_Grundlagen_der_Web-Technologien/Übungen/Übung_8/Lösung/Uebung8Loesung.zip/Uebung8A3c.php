<?php 
$produkt = array();
$produkt[0]['Produktname'] = "Bohrmaschine";
$produkt[0]['Preis'] = 45;
$produkt[0]['Anzahl'] = 6;
$produkt[1]['Produktname'] = "Kreissäge";
$produkt[1]['Preis'] = 79;
$produkt[1]['Anzahl'] = 0;
$produkt[2]['Produktname'] = "Bandschleifer";
$produkt[2]['Preis'] = 89;
$produkt[2]['Anzahl'] = 15;
foreach ($produkt as $ebene1) {
    foreach ($ebene1 as $feldname => $ebene2) {
        print $feldname . ": " . $ebene2 . "<br>\n";
    }
    print "<br>";
}
?>