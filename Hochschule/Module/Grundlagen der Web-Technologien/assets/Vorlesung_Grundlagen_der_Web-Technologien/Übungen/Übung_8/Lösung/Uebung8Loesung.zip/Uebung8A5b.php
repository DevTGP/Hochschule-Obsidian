<?php class Produkt
{
    private $artikelnummer;
    private $produktname;
    private $preis;
    private $beschreibung;
    private $anzahl;
    public function setArtikelnummer($wert)
    {
        $this->artikelnummer = $wert;
    }
    public function setProduktname($wert)
    {
        $this->produktname = $wert;
    }
    public function setPreis($wert)
    {
        $this->artikelnummer = $wert;
    }
    public function setBeschreibung($wert)
    {
        $this->beschreibung = $wert;
    }
    public function setAnzahl($wert)
    {
        $this->anzahl = $wert;
    }
}
?>