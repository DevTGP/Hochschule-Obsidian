<?php 
include("Uebung8A5b.php");
$Bohrmaschine = new Produkt();
$Bohrmaschine->setArtikelnummer(1);
$Bohrmaschine->setProduktname("Bohrmaschine");
$Bohrmaschine->setPreis(45);
$Bohrmaschine->setBeschreibung("Kraftvolle Bohrmaschine für Bohr- und Schraubarbeiten");
$Bohrmaschine->setAnzahl(23);
?>