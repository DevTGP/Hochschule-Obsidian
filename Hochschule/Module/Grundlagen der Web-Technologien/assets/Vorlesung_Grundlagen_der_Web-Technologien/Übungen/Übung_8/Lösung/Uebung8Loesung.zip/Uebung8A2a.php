<?php 
$bestand = 4;
if ($bestand == 0) {
    print "Der gewünschte Artikel ist leider nicht mehr verfügbar.";
}
?>