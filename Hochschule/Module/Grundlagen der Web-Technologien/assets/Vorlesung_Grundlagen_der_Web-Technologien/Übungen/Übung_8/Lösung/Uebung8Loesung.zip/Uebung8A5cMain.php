<?php 
include ("Uebung8A5c.php"); 
$meinAuto = new Auto(); 
$meinAuto->geschwindigkeit = 150; 
$meinAuto->kraftstoffverbrauch = 7; 
print "Geschwindigkeit: ".$meinAuto->geschwindigkeit." km/h<br>\n"; 
print "Kraftstoffverbrauch: ".$meinAuto->kraftstoffverbrauch." l/100km<br>\n"; 
$meinAuto->setSitzplaetze (2); 
print "Sitzplätze: ".$meinAuto->getSitzplaetze()."<br>\n"; 
?>