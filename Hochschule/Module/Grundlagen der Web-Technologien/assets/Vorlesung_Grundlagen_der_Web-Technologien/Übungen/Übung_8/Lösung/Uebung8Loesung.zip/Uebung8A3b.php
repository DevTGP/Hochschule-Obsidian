<?php 
$sortiment = array();
$sortiment[0]['Produkt'] = "Apfel";
$sortiment[0]['Preis'] = 1.99;
$sortiment[0]['Sonderangebot'] = false;
$sortiment[1]['Produkt'] = "Birne";
$sortiment[1]['Preis'] = 0.99;
$sortiment[1]['Sonderangebot'] = true;
$sortiment[2]['Produkt'] = "Tomate";
$sortiment[2]['Preis'] = 2.49;
$sortiment[2]['Sonderangebot'] = false;
$sortiment[3]['Produkt'] = "Zucchini";
$sortiment[3]['Preis'] = 1.49;
$sortiment[3]['Sonderangebot'] = false;
foreach ($sortiment as $inhalt) {
    if ($inhalt['Sonderangebot']) {
        print "Achtung Sonderangebot!<br>\n";
    }
    print $inhalt['Produkt'] . "<br>\n";
    print $inhalt['Preis'] . "<br><br>\n";
}
?>
