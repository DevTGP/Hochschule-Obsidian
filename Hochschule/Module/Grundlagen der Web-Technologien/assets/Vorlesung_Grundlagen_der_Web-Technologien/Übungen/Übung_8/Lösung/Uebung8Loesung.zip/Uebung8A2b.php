<?php 
$produkt = array('Produktname' => "Bohrmaschine", 'Preis' => 15, 'Anzahl' => 3);

if ($produkt['Anzahl'] == 0) {
    print "Das Produkt " . $produkt['Produktname'] . " ist leider nicht mehr verfügbar.";
} elseif ($produkt['Preis'] >= 20) {
    print "Das Produkt " . $produkt['Produktname'] . " ist verfügbar und wird versandkostenfrei geliefert.";
} else {
    print "Das Produkt " . $produkt['Produktname'] . " ist verfügbar. Für die Lieferung fallen 5 Euro Versandkosten an.";
}
?>