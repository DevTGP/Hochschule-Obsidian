<?php 
$teil1 = "Freude, schöner Götterfunken,";
$teil2 = "Tochter aus Elysium,";
$teil3 = "wir betreten feuertrunken,";
$teil4 = "Himmlische, dein Heiligtum.";
print "<p>" . $teil1 . "<br>\n" . $teil2 . "<br>\n" . $teil3 . "<br>\n" . $teil4 . "</p>\n";
?>