<?php 
include ("Uebung8A4b.php"); 
ausgabe (potenz(2)); 
?>