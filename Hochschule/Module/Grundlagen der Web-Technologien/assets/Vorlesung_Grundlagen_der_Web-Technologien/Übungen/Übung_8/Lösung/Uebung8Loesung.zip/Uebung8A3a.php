<?php $i = 0;
while ($i < 10) {
    $i++;
    print $i . "<br>\n";
} ?> 

<?php for ($i = 0; $i < 10; $i++) {
    print ($i + 1) . "<br>\n";
} ?> 

<?php $i = 0;
do {
    print ($i + 1) . "<br>\n";
    $i++;
} while ($i < 10); ?> 