<?php 
class Produkt { 
    private $artikelnummer; 
    private $produktname; 
    private $preis; 
    private $beschreibung; 
    private $anzahl; } 
?> 