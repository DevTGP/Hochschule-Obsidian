<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta name="language" content="de">
<meta name="author" content="taz, die tageszeitung">
<meta name="publisher" content="taz, die tageszeitung">
<meta name="copyright" content="Contrapress Media GmbH">
<meta name="description" content="taz, die tageszeitung ">
<meta name="keywords"  content="taz,tageszeitung,Politik,Umwelt,Gesellschaft,Kultur,Hintergrund,Magazin,gr�ne Politik,linke Politik,Zeitgeschehen,Berlin,Lokalteile,Nachrichten,Kommentare,Debatte,Schlagzeilen,TOM Comic,Tom,Cartoons,Karikaturen,politische Karikatur">
<meta name="page-type" content="Bericht Reportage">
<meta name="audience" content="Alle">
<meta name="robots" content="index,follow">
<meta name="robots" content="noarchive">
<meta name="revisit-after" content="1 day">
<link rel="SHORTCUT ICON"  href="favicon.ico"> 
<title>taz, die genossenschaft</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script language="JavaScript" type="text/javascript">
<!--
function frTest() {
  if(top != self) {    var appVer = navigator.appVersion;
    var NS = (navigator.appName == 'Netscape') && ((appVer.indexOf('3') != -1) || (appVer.indexOf('4') != -1));
    var MSIE = (appVer.indexOf('MSIE 4') != -1);

    if (NS || MSIE) {
      top.location.replace(window.location.href);
    } else {
      top.location.href = window.location.href;
    }
  }
}
//-->
</script>
</head>
<body bgcolor="#666666" onLoad="frTest()">
<a name="anfang"></a>
<table width="100%" style="background-image:url(/taz/gifs/test1.gif)" cellpadding="5" cellspacing="0" border="0">
<tr>
<td valign="top" align="center">
<a href="pt/etc/nf/abo/aboform7">
        <img src="http://www.taz.de/taz/gifs/kurzabo.gif" border="0" height="60" width="140" alt="taz-Kurzabo"></a></td>
<td valign="top" align="center">
<a href="http://www.versiko.de/taz" target="_blank">
  <img src="http://www.taz.de/taz/anz/gifs/versiko1.gif" height="60" width="140" border="0" alt="Versiko"></a></td>
 <td valign="top" align="center">
 <a href="http://www.taz.de/pt/.etc/nf/kg/ideale">
  <img src="http://www.taz.de/taz/gifs/tazekg.gif" border="0" height="60" width="140" alt="taz Entwicklungs KG"></a></td>
<td valign="top" align="center">
  <a href="http://www.freiabos.de/">
  <img src="http://www.taz.de/taz/anz/gifs/Freiabos_ani.gif" border="0" height="60" width="140" alt="Freiabos f&uuml;r Gefangene"></a></td>

</tr>
</table>
<table width="100%" cellpadding="2" cellspacing="0" border="0"  bgcolor="#e0e0e0">
  <tr>
    <td>
      <p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.archiv/suche.demo,1">Archiv</a></p>    </td>
    <td>
      <p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.etc/nf/recherche/recherche1">Recherchedienst</a></p>
    </td>
    <td>
      <p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.etc/nf/impressum">Impressum</a></p>
    </td>
    <td>
      <p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.etc/nf/abo/praemien">Abo</a></p>
    </td>
    <td>
   <p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.etc/nf/anzeigen/neuemedia">Anzeigen</a></p>
    </td>
    <td>
    <p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.etc/nf/tazshop/tazshop">tazshop</a></p>
    </td>
    <td>
    <p class="c"><a href="genossenschaft.html">taz-Genossenschaft</a></p>
    </td>
    <td>
<p class="c">&nbsp;&nbsp;<a href="http://www.taz.de/pt/.etc/nf/ueberuns/ueberuns">&uuml;ber uns</a></p>
    </td>
    <td>
    <p class="c"><a href="http://www.taz.de/pt/2005/03/11.nf/brief.TextName, ">Kontakt</a></p>
    </td>
  </tr>
</table>
<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
  <tr>
    <td>
      <a href="pt/.nf/home">
      <img src="http://www.taz.de/taz/gifs/tazlo1.gif" width="261" height="59" alt="die tageszeitung" border="0"></a>
    </td>
<td>
<script language="JavaScript" type="text/javascript"> <!--
  rand = (""+Math.random());
  len = rand.length;
  append = rand.substr(len-10,10);
  var IVW="/pt/cntres/Genossenschaftsseite/ecnt/"+append+".taz/countergif";
  document.write("<img src=\""+IVW+"\" width=\"1\" height=\"1\" alt=\"zaehler\">");
// -->
</script> 
<noscript>
<img src="pt/cntres/Genossenschaftsseite/ecnt/1110566909.taz/countergif" width="1" height="1" alt="zaehler"> 
</noscript>
</td>
    <td>
      <p class="d">11.3.2005      <img src="http://www.taz.de/taz/gifs/tr.gif" width="15" height="2" alt="die tageszeitung">
      </p>
    </td>
  </tr>
</table>
      <table width="100%" cellpadding="1" cellspacing="0" border="0" bgcolor="#e0e0e0"><tr><td align="center"><a href="pt/.nf/home"><img src="http://www.taz.de/taz/gifs/home2.gif" border="0" width="59" height="15" alt="startseite"></a></td><td align="center"><a href="http://www.taz.de/pt/.nf/regionalausgaben"><img src="http://www.taz.de/taz/gifs/regionalausgaben.gif" border="0" width="103" height="15" alt="Regionalausgaben"></a><td align="center"><a href="http://www.taz.de/pt/2005/03/05.nf/magIndex"><img src="http://www.taz.de/taz/gifs/tazmag2neu.gif" border="0" width="99" height="15" alt="magazin"></a></td><td align="center"><a href="http://www.taz.de/pt/2005/03/11.nf/mondeIndex"><img src="http://www.taz.de/taz/gifs/monde2neu.gif" border="0" width="128" height="15" alt="LeMondediplomatique"></a></td><td align="center"><a href="http://www.taz.de/pt/.nf/tunnelnf"><img src="http://www.taz.de/taz/gifs/tomtu2neu.gif" border="0" width="66" height="15" alt="tomtunnel"></a></td></tr></table><table width="100%" cellpadding="15" cellspacing="1" border="0">
<tr><td valign="top" bgcolor="#e0e0e0" width="180">
<ul class="l">
<li><b>taz-Genossenschaft</b></li>
<li><a href="genossenschaft.html">
      Was&nbsp;ist&nbsp;die&nbsp;taz-Genossenschaft?</a></li>
<li><a href="genofunktion.html">
      Wie&nbsp;funktioniert&nbsp;die&nbsp;Genossenschaft?</a></li>
<li><a href="vorteile.html">
      Was&nbsp;habe&nbsp;ich&nbsp;davon?</a></li>
<li><a href="beteiligung.html">
    Wie&nbsp;werde&nbsp;ich&nbsp;GenossIn?</a></li>
<li><a href="broschuere.html">Wie&nbsp;bekomme&nbsp;ich&nbsp;die&nbsp;Brosch&uuml;re?</a></li>
</ul>
<br />
<ul class="l">
<li><b>Hintergrund</b></li>
<li><a href="editorial.html">Bedeutung der taz</a></li>
<li><a href="team.html">Geschichte&nbsp;der&nbsp;Genossenschaft</a></li>
<li><a href="satz.html">Satzung&nbsp;der&nbsp;Genossenschaft</a></li>
<li><a href="chefredaktion.html">Die Zeitung</a></li>
<li><a href="unternehmen.html">Das Unternehmen</a></li>
</ul>
<br />
<ul class="l">
<li><b>F&uuml;r GenossInnen</b></li>
<li><a href="praemien.html">Anteile aufstocken</a></li>
<li><a href="reise.html">taz-Wanderreise</a></li>
<li><a href="aktuelles.html">Aktuelles</a></li>
<li><a href="http://www.taz.de/taz/gifs/newsletter_02_2004.pdf">aktueller&nbsp;Rundbrief</a>&nbsp;(PDF)</li>
</ul>
<br />
<ul class="l">
<li><b>taz-Beteiligungsm&ouml;glichkeit:</b></li>
<li><a href="http://www.taz.de/pt/.etc/nf/kg/ideale">taz&nbsp;Entwicklungs&nbsp;KG</a></li>
</ul>
<img src="http://www.taz.de/taz/gifs/tr.gif" width="100" height="10" border="0" alt="">
<table cellpadding="2" cellspacing="0" border="0">
<tr><td bgcolor="#cccccc" align="center">
      <p>
      TOMs Teufel als Dauerkalender aus Emaille
      f&uuml;r alle 
<a href="broschuere.html">Neumitglieder</a>
und alle, die ihren Anteil aufstocken.</p>
<img src="http://www.taz.de/taz/gifs/tomschild.jpg" width="190" height="284" border="0" alt="TOM-Blechkalender">
</td></tr>
</table>
   </td>
<td valign="top" bgcolor="#ffffff">
  <h4 class="rot">Was habe ich davon?</h4>
	<p>
	Die GenossInnen sichern die wirtschaftliche und publizistische Unabh&auml;ngigkeit der taz. Die Fr�chte dessen halten sie tazt&auml;glich mit ihrer Zeitung in H&auml;nden.
	Sie w&auml;hlen bei der j&auml;hrlichen Generalversammlung den Aufsichtsrat und bestimmen, was mit ihren Einlagen passiert. Sie werden regelm&auml;&szlig;ig mit dem Geno-Newsletter &uuml;ber die aktuelle Situation informiert.
	</p><p>Und es gibt auch ein paar <b><span class="rot">materielle Vorteile</span></b>:
	</p>
	<ul><li>Teilnahme an 
<a href="reise.html">Reisen</a>, Weinverkostungen und anderen Aktionen</li>
	<li>10 % Rabatt im <a href="http://www.taz.de/pt/.etc/nf/tazshop/tazshop">tazshop</a></li>
	<li>Verg&uuml;nstigungen bei <a href="http://www.taz.de/pt/.etc/nf/recherche/recherche1">Recherche-Auftr&auml;gen</a></li>
	<li>Pr&auml;mie beim Beitritt:</li>
	</ul>
	<img src="gifs/tazpressoset.jpg" border="0" width="125" height="74" alt="tazpresso-Set" align="left"  hspace="10">
	<p><b><span class="rot">tazpresso-Set</span></b><br />
	bestehend aus 250 g gemahlenem tazpresso, 2 Espressotassen von Seltmann-Weiden, 
	2&nbsp;Latte-Macchiato-Gl&auml;sern, der Kaffeedose sowie
	der Kakao-Schablone f&uuml;r die tazze auf dem Milchschaum.
	</p>
	<img src="gifs/ruckpraemie.jpg" width="125" height="171" border="0" alt="Rucksack" align="right">
	<p>
	<b><span class="rot">taz-Rucksack</span></b><br />
	Hochwertiger Rucksack der Firma Deuter im rot-schwarzen Design.
	Volumen 25 Liter, Gewicht 520 Gramm,
	abnehmbarer H&uuml;ftgurt und flexibler Gummizug vorne.
Kleines Innenfach f�r Discman oder Handy mit innovativem Kabelauslass. 
Gro&szlig;es Innenfach f&uuml;r den sicheren Transport von Papieren,
kleines Au&szlig;enfach mit Schl&uuml;sselkarabiner.
	</p>
	<img src="gifs/saunatuch.jpg" width="100" height="77" border="0"alt="Badetuch" align="left">
	<p><b><span class="rot">taz-Bade-/Saunatuch</span></b><br />
	2 qm rotes Frottee mit silbernem taz-Logo.</p>
	<img src="gifs/archivdvd.gif" width="100" height="101" border="0" alt="taz-Archiv-DVD" align="right">
	<p>
	<b><span class="rot">taz-Archiv-DVD</span></b><br />
mit den taz-Artikeln vom 1.9.1986 bis 30.9.2004, allen Texten der <i>Monde&nbsp;diplomatique</i> seit Mai 1995, 2833&nbsp;&copy;TOM Touch&eacute;s  
 sowie 1 Jahr lang Zugang zum taz-online-Archiv.
F&uuml;r Windows, Linux und Macintosh,
<a href="pt/etc/nf/dvd">mehr Infos zur DVD</a>.</p>
	<img src="gifs/genouhr.jpg" width="150" height="80" border="0" alt="Armbanduhr" align="left"  hspace="10">
	<p><b><span class="rot">taz-Armbanduhr</span></b><br />Schlichte Eleganz mit Pr&auml;zisionslaufwerk, mattsilberner Fassung und schwarzem Lederarmband.</p>
	<img src="gifs/mangopr.jpg" width="150" height="129" border="0" alt="Mangopaket" align="right">
	<p>
	   <b><span class="rot">Das fair gehandelte Mango-Paket</span></b><br />
	  Der Geschenkkarton enth&auml;lt 5 Mangospezialit&auml;ten von den Philippinen:
	  Fruchtaufstrich, Fruchtessig, Lik&ouml;r, Sirup und getrocknete Mangos.
	  Die Mangos werden von Kleinbauern auf nat�rliche Weise ohne Einsatz von Chemie angebaut.
	  Der Handel mit den Mangoprodukten sichert ihre Existenz und verschafft neue wirtschaftliche
	  und soziale Perspektiven. Die Existenzsicherung der Landbev&ouml;lkerung ist dar&uuml;ber hinaus ein
entscheidender Schritt gegen die Kinderprostitution.  Weitere Informationen:
<a href="http://www.taz.de/pt/2003/10/04/a0092.nf/text" target="new">taz-Artikel vom 4.10.2003</a> und
     <a href="http://www.preda.org/" target="new">www.preda.org</a>
       </p>
<p>
<a href="broschuere.html">Brosch&uuml;re bestellen</a>
</p>
<p>
<a href="vorteile.html.php#anfang">Seitenanfang</a>
</p>
</td>
</tr>
</table>
</body>
</html>
