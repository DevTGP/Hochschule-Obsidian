"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


## Listen anlegen, verschachteln und ändern
###############################################################################

# Listen werden in [...] geschrieben, die Reihenfolge der Elemente ist wichtig!
[10, 20, 30, 40]                                # alle Elemente vom Typ int
['crunchy frog', 'ram bladder', 'lark vomit']   # alle Elemente vom Typ str
['spam', 2.0, 5, [10, 20]]                      # Elemente verschiedenen Typs
[]                                              # leere Liste

# Zuweisung zu Variablen, siehe Variable Explorer
kaesesorten = ['Cheddar', 'Edamer', 'Gouda']
zahlen = [17, 123]
verschachtelt = ['spam', 2.0, 5, [10, 20]]
leer = []
print(kaesesorten, zahlen, verschachtelt, leer)
# Ausgabe: ['Cheddar', 'Edamer', 'Gouda'] [17, 123] ['spam', 2.0, 5, [10, 20]] []


# Zugriff auf Listenelemente, Indexbereich wie bei Strings
kaesesorten[0]
# Ausgabe: 'Cheddar'
zahlen[2]
# Ausgabe: IndexError: list index out of range
verschachtelt[3]
# Ausgabe: [10, 20]
leer[0]
# Ausgabe: IndexError: list index out of range


# Listen können geändert werden: Klammeroperator links erlaubt
zahlen
# Ausgabe: [17, 123]
zahlen[1] = 5
zahlen
# Ausgabe: [17, 5]

verschachtelt
# Ausgabe: ['spam', 2.0, 5, [10, 20]]
verschachtelt[-1] = 'hier war eine Liste'       # neg. Index von links
verschachtelt
# Ausgabe: ['spam', 2.0, 5, 'hier war eine Liste']

# Überprüfen, ob ein Element in der Liste ist mit in-Operator
'Edamer' in kaesesorten
# Ausgabe: True
'Brie' in kaesesorten
# Ausgabe: False





## Iteration, Operationen, Slicing und Listen-Methoden
###############################################################################

# Iteration über alle Elemente in Reihenfolge
for kaese in kaesesorten:
    print(kaese)
# Ausgabe:
# Cheddar
# Edamer
# Gouda

for x in []:
    print('Das wird niemals ausgegeben.')
# Ausgabe:


# die eingebaute Funkion range(n,m) liefert den Bereich n, n+1, ...., m-1  
for i in range(3, 7):   # n: einschließlich, m: ausschließlich
    print(i)
# Ausgabe:
# 3
# 4
# 5
# 6

# bei nur einem Argument geht es immer bei n=0 los
for i in range(4):      # 4 Iterationen von 0, ..., 3
    print(i)
# Ausgabe:
# 0
# 1
# 2
# 3

# die eingebaute Funktion len() liefert die Anzahl der Elemente in einer Liste
len(kaesesorten)
# Ausgabe: 3
len([])
# Ausgabe: 0
len(['a', ['b', 'c']])      # nur auf oberster Ebene!
# Ausgabe: 2

# Anwendung von len/range bei Listen für expliziten Index
zahlen = [17, 123, 42]
for i in range(len(zahlen)):    # zulässiger Bereich: 0 bis len(zahlen)-1 
    zahlen[i] = zahlen[i] * 2   # 1. rechte Seite: alten Wert lesen und verdoppeln
                                # 2. Zuweisung: neuen Wert an gleicher Stelle speichern
zahlen
# Ausgabe: [34, 246, 84]

# die Operatoren + und * auf Listen
a = [1, 2, 3]
b = [4, 5, 6]
c = a + b           # Konkatenation (= Hintereinanderschreibung) 
c
# Ausgabe: [1, 2, 3, 4, 5, 6]

[0] * 4             # Wiederholung (= mehrfache Konkatenation)
# Ausgabe: [0, 0, 0, 0]

[1, 2, 3] * 3
# Ausgabe: [1, 2, 3, 1, 2, 3, 1, 2, 3]

# Slicing bei Listen
t = ['a', 'b', 'c', 'd', 'e', 'f']
t[1:3]  
# Ausgabe: ['b', 'c']

t[:4]   # von Anfang an bis 4 ausschließlich  
# Ausgabe: ['a', 'b', 'c', 'd']

t[3:]   # ab 3 einschließlich bis zum Ende
# Ausgabe: ['d', 'e', 'f']

# gesamtee List kopieren(!) 
t[:]
# Ausgabe: ['a', 'b', 'c', 'd', 'e', 'f']

# mehrere Listen-Elemente mit Slicing auf einmal ändern
t[1:3] = ['x', 'y']     # rechts muss eine Liste stehen
t
# Ausgabe: ['a', 'x', 'y', 'd', 'e', 'f']

# Methoden auf Listen
t = ['a', 'b', 'c']
t.append('d')       # am Ende von t anfügen
t
# Ausgabe: ['a', 'b', 'c', 'd']

t1 = ['a', 'b', 'c']
t2 = ['d', 'e']     
t1.extend(t2)       # alle Elemente aus t2 an t1 anfügen (mehrfaches append)
t1
# Ausgabe: ['a', 'b', 'c', 'd', 'e']

t = ['d', 'c', 'e', 'b', 'a']
t.sort()            # t aufsteigend sortieren
t
# Ausgabe: ['a', 'b', 'c', 'd', 'e'] 
 
# die obigen Methoden ändern die änderbaren(!) Liste





## Reduzieren, Filtern, Umwandeln, Löschen, Vergleich mit Strings 
###############################################################################

# Reduzieren, z.B. auf die Summe aller Elemente
def addiere_alle(t):
    summe = 0
    for x in t:
        summe += x      # kurz für: summe = summe + x
    return summe

t = [1, 2, 3]
addiere_alle(t)
# Ausgabe: 6

# die eingebaute Funktion sum übernimmt das
sum(t)
# Ausgabe: 6

# Umwandeln, z.B. alle Elemente in Großbuchstaben
def alles_gross(t):
    res = []                            # Neue Ergebnisliste
    for s in t:
        res.append(s.capitalize())      # passende String-Methode
    return res                          # t bleibt unverändert

t = ['hallo', 'welt']
alles_gross(t)
# Ausgabe: ['Hallo', 'Welt']
t
# Ausgabe: ['hallo', 'welt']
    
# Filtern, z.B. nur Strings in Großbuchstaben übernehmen
def nur_grosse(t):
    res = []
    for s in t:
        if s.isupper():
            res.append(s)
    return res

t = ['Hallo', 'WELT', 'Python', 'CODE']
nur_grosse(t)
# Ausgabe: ['WELT', 'CODE']

# Entfernen von Elementen: pop, del, remove
t = ['a', 'b', 'c', 'd']
x = t.pop(1)        # entfernt das Element an der angegebenen Position und liefert es zurück
t
# Ausgabe: ['a', 'c', 'd']
x
# Ausgabe: 'b'
t.pop()             # entfernt das letzte Element
# Ausgabe: 'd'
t
# Ausgabe: ['a', 'c']
[].pop()
# Ausgabe: IndexError: pop from empty list

# del-Operator: Entfernen ohne Rückgabewert
t = ['a', 'b', 'c', 'd']
del t[1]    # Operatorschreibweise, alternativ: Funktionsaufruf del(t[1])
t
# Ausgabe: ['a', 'c', 'd']

# remove, falls Index unbekannt
t = ['a', 'b', 'c', 'b']
t.remove('b')   # erstes Auftreten wird entfernt, Rückgabe None     
t
# Ausgabe: ['a', 'c', 'b']
t.remove('x')   # aber das Element muss auch da sein!
# Ausgabe: ValueError: list.remove(x): x not in list

# Löschen von mehreren Elementen mit Slicing und del
t = ['a', 'b', 'c', 'd', 'e', 'f']
del t[1:5]
t
# Ausgabe: ['a', 'f']

# Strings und Listen haben verschiedenen Typ: str <-> List
# list(): str -> list
s = 'spam'
t = list(s) # Liste aller Zeichen
t
# Ausgabe: ['s', 'p', 'a', 'm']

# split(): str -> list
s = 'Sehnsucht nach den Fjorden'
t = s.split()   # Liste aller Wörter
print(t)
# Ausgabe: ['Sehnsucht', 'nach', 'den', 'Fjorden']

# das Standardtrennzeichen ist ' ', aber das kann man ändern
s = 'spam-spam spam-spam'
trennzeichen = '-'      # darf nicht leer sein
s.split(trennzeichen)
# Ausgabe: ['spam', 'spam spam', 'spam']

# join(): str, list -> str
t = ['Sehnsucht', 'nach', 'den', 'Fjorden']
trennzeichen = ' '       # Methode auf dem Trennzeichen, mit zusätzl. Listenargument   
trennzeichen.join(t)     # liefert String aller konkatenierten Listenelemente
# Ausgabe: 'Sehnsucht nach den Fjorden'
t = ['Dies', 'wird', 'ein', 'einziges', 'Wort']
''.join(t)     # hier darf das Trennzeichen leer sein
# Ausgabe: 'DieswirdeineinzigesWort'


## gleich oder nicht gleich
###############################################################################

a = 'banane'
b = 'banane'
id(a) == id(b)
# Ausgabe: True
a is b          # Test mit dem is-Operator
# Ausgabe: True

a = [1, 2, 3]
b = [1, 2, 3]
id(a) == id(b)
# Ausgabe: False
a is b
# Ausgabe: False

# der Unterschied ist bei den Werten im Variable Explorer nicht erkennbar
# aber verschiedene Typen haben verschiedene Farben

a[1] = 5
b[1] == 5
# Ausgabe: False

# Aliasing
a = [1,2,3]
b = a           # ist ein Alias für das Objekt [1,2,3]
id(a) == id(b)
# Ausgabe: True
a is b
# Ausgabe: True

a[1] = 5
b[1] == 5
# Ausgabe: True


## Funktionsaufrufe mit Listen
###############################################################################

buchstaben = ['a', 'b', 'c']    # buchstaben ist Referenz auf ['a', ...]

# Call by Object Reference: Parameter t verweist beim Aufruf 
# der Funktion auf dieselbe Speicherstelle wie das Argument 
def loesche_ersten(t):      
    del t[0]                # referenzierte Liste wird verändert

loesche_ersten(buchstaben)  # die Referenz auf ['a', ...] wird an den Parameter t übergegeben
buchstaben                  # Effekt: Änderung an aufrufender Stelle!
# Ausgabe: ['b', 'c']


# Welche Operationen ändern die Liste, welche erstellen Kopien?

# Methode append hat keinen Rückgabewert, aber ändert die Liste
t1 = [1, 2]
t2 = t1.append(3)
t1
# Ausgabe: [1, 2, 3]
print(t2)
# Ausgabe: None

# der Operator + erzeugt stets eine Kopie seiner Argumente
t3 = t1 + [4]   # Elemente aus t1 werden kopiert und mit 4 in eine neue Liste geschrieben
t1
# Ausgabe: [1, 2, 3]
t3
# Ausgabe [1, 2, 3, 4]
t3[0] = 0
t3
# Ausgabe [0, 2, 3, 4]
t1
# Ausgabe: [1, 2, 3]

# auch Slicing [:] erstellt stets eine Kopie
def falsch_loesche_ersten(t):
    t = t[1:]   # Parameter t verweist auf eine Kopie ab Index 1

t4 = [1, 2, 3]
falsch_loesche_ersten(t4)
t4
# Ausgabe: [1, 2, 3]

# viel besser lesbar: mit explizitem (!) Rückgabewert
def rest(t):
    return t[1:]    # Rückgabe der veränderten Kopie

buchstaben = ['a', 'b', 'c']
rest = rest(buchstaben)
rest
# Ausgabe: ['b', 'c']
buchstaben      # Argument bleibt unverändert
# Ausgabe: ['a', 'b', 'c']

