"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# auf MacOS ist die Ausführung ggf über die Konsole notwendig
#   (Problem beim Aufruf von Turtle aus einer IDE heraus)
#

import turtle
import math            

# Ziel: Kreisbogen gemäß vorgegebenem Winkel zeichnen
# 
# aber Funktionen kreis und polygon nicht unverändert verwendbar
# obwohl beide Aspekte vorkommen
#
# def bogen(t, r, winkel):                    # neuer Parameter winkel
#     # der erste Teil ist wie in kreis, aber auf die Bogenlänge eingeschränkt
#     bogen_laenge = 2 * math.pi * r * winkel / 360     
#     n = int(bogen_laenge / 3) + 1           
#     schritt_laenge = bogen_laenge / n
#     # der zweite Teil ist wie in polygon, aber nur gemäß winkel
#     schritt_winkel = float(winkel) / n      
#     for i in range(n):
#         t.fd(schritt_laenge)                
#         t.lt(schritt_winkel)

# bob = turtle.Turtle()   # bob ist immer noch unser Zeichenstift
# bogen(bob, 50, 90)


# funktioniert zwar, aber Ähnlichkeiten sind Anlass zum Refactoring!

# Ein polygon mit Einschränkung auf winkel ist kein Polygon (= geschlossener Streckenzug) mehr
# daher Generalisierung zu polylinie (= Streckenzug, nicht unbedingt geschlossen)
#
def polylinie(t, n, laenge, winkel):
    for i in range(n):
        t.fd(laenge)
        t.lt(winkel)    

# polygon ist dann eine spezielle polylinie: winkel ergibt sich aus der Eckenzahl
def polygon(t, n, laenge):
    winkel = 360.0 / n              # Winkel wird so gewählt, dass Streckenzug geschlossen
    polylinie(t, n, laenge, winkel)

# bogen ist eine andere spezielle polylinie, bei der Radius und Winkel gegeben sind: 
def bogen(t, r, winkel):
    bogen_laenge = 2 * math.pi * r * winkel / 360   # alles wie in der ersten Version oben
    n = int(bogen_laenge / 3) + 1
    schritt_laenge = bogen_laenge / n
    schritt_winkel = float(winkel) / n
    polylinie(t, n, schritt_laenge, schritt_winkel) # nur dieser Aufruf ist neu

# und kreis ist ein spezieller bogen mit 360 Grad
def kreis(t, r):
    bogen(t, r, 360)


bob = turtle.Turtle()   # bob ist immer noch unser Zeichenstift

bogen(bob, 50, 90)
kreis(bob, 150)


turtle.mainloop()       # warte auf Eingaben (nur Fenster schließen möglich)



