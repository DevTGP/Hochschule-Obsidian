"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# auf MacOS ist die Ausführung ggf über die Konsole notwendig
#   (Problem beim Aufruf von Turtle aus einer IDE heraus)
#


import turtle           
bob = turtle.Turtle()   


# Datenkapselung: Benennen und Wiederverwenden von Anweisungen
def quadrat(t):         # Parameter t: turtle
    for i in range(4):      # Body der Funktion eingerückt
        t.fd(100)               # Body der for-Anweisung nochmal eingerückt
        t.lt(90)


# hier sind wir wieder in __main__
quadrat(bob)


alice = turtle.Turtle() # eine andere Schildkröte
alice.pu()              # mit einer etwas anderen Ausgangsposition
alice.fd(10)
alice.rt(90)
alice.fd(10)
alice.lt(90)
alice.pd()
alice._delay(100)        # alice ist nicht so schnell
quadrat(alice)          # aber dann: dieselbe Funktion aufrufen     


turtle.mainloop()       # warte auf Eingaben (nur Fenster schließen möglich)



