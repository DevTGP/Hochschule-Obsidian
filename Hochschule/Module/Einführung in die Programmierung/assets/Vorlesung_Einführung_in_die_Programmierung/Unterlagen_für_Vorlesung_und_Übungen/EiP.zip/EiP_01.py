"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

# Starten des interaktiven Python-Interpreters und Ausführen von einfachem Code
# es erscheit der sog. primary prompt


## Verwendung als Taschenrechner
###############################################################################

1 + 1 
# Ausgabe: 2

23 + 7
# Ausgabe 30

1 - 7
# Ausgabe -6


# Erstes Programm: "Hallo, Welt!" ausgeben
#   alle Anweisungen werden sofort ausgefuehrt
print('Hallo, Welt!')
# Ausgabe: Hallo, Welt!


# print() ist eine Anweisung, die die übergebenen Daten auf dem Bildschirm unverändert ausgibt
# die Hochkommata '....' kennzeichnen die Daten als Zeichenkette
#   später mehr zu verschiedenen Arten von Daten
# die Daten selbst sind: Hello, World!

# help-Fenster -> print, oder
help(print)



# Arithmetische Operatoren verwenden
40 + 2 
# Ausgabe: 42 

43 - 1 
# Ausgabe: 42 

6 * 7 
# Ausgabe: 42 als ganze Zahl ohne Nachkommastellen   

84 / 2 
# Ausgabe: 42.0  # Division mit "/" ergibt stets eine Fließkommazahl

# Potenzierung durchführen
6**2 + 6 
# Ausgabe: 42
(6 ** 2) + 6 
# Ausgabe: 42
6 ** (2 + 6) 
# Ausgabe: 1679616
# ** bindet stärker als +
# mit der Festlegung von Bindungsreihenfolgen für Operatoren werden Klammern gespart


# Bitweiser Operator XOR (Symbol ^) angewendet auf Zahlen in Dezimaldarstellung
6 ^ 2 
# Ausgabe: 4  # Achtung: ^ ist der bitweise XOR-Operator, nicht die Potenzierung!
# 6 in Binärdarstellung: 110
# 2 in Binärdarstellung: 010
# bitweise entweder-oder 100 
# 4 in Binärdarstellung: 100



## Werte und Typen
###############################################################################

# Den Typ eines Wertes ermitteln
type(2) 
# Ausgabe: int

type(42.0) 
# Ausgabe: float

type('Hello, World!') 
# Ausgabe: str

# Strings, die wie Zahlen aussehen, bleiben Strings
type('2') 
# Ausgabe: str

type('42.0') 
# Ausgabe: str

# Vorsicht bei der Verwendung von Kommata in Zahlen
1,000,000 
# Ausgabe: (1, 0, 0)  # Python interpretiert dies als eine Sequenz von Integerwerten






