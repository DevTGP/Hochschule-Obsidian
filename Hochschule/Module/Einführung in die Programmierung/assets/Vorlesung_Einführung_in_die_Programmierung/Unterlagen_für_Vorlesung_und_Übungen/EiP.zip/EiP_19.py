"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


##  Weitere Features
###############################################################################


# Bedingte Ausdrücke: mit if...else

import math

x = 3
# häufiger Fall: if/else-Anweisung bei unterschiedlichen Zuweisungen an gleiche Variable 
if x > 0:
    y = math.log(x)
else:
    y = float('nan')    # spezielles Symbol für "not a number"

# stattdessen: bedingter Ausdruck, rechts von =
y = math.log(x) if x > 0 else float('nan')  # Semantik wie oben

# Bsp aus Kap 6
def fakultaet(n):
    if n == 0:
        return 1
    else:                               # n >= 1
        return n * fakultaet(n-1)

# kürzere Alternative
def factorial(n):
    return 1 if n == 0 else n * factorial(n-1)


# List Comprehension

# häufiger Fall: alle Elemente einer Liste verarbeiten und Ergebnis in neue Liste schreiben

# Bsp aus Kap 10 
def alles_gross(t):         
    res = [] 
    for s in t:
        res.append(s.capitalize())
    return res

# stattdessen: 
def alles_gross(t):
    return [s.capitalize() for s in t]

# Filter-Bsp aus Kap 10 
def nur_grosse(t):
    res = []
    for s in t:
        if s.isupper():
            res.append(s)
    return res

# mit if auch als Filter verwendbar
def nur_grosse(t):
    return [s for s in t if s.isupper()]



# Generator-Ausdrücke

g = (x**2 for x in range(5))    # runde Klammern!
g
# Ausgabe: <generator object <genexpr> at 0x16a642c20>


# Zustand wird gemerkt
next(g)
# Ausgabe: 0
next(g)
# Ausgabe: 1
for val in g:       # beginnt bei x = 2
    print(val)
# Ausgabe:
# 4
# 9
# 16
next(g)
# Ausgabe: StopIteration    (Ausnahme)

# oft sehr nah an der mathematischen Notation
sum(x**2 for x in range(5))



# any und all

# "Großes ODER": Ist mind. EIN Ausdruck True?
expr_list = [False, True, False, True]
res = False 
for expr in expr_list:
       if expr:
           res = True       # wird nie wieder False
res

# stattdessen
any([False, False, True])   # Sequenz als Argument
# Ausgabe: True

# oft zusammen mit Generator-Ausdruck
any(zeichen == 't' for zeichen in 'monty')
# Ausgabe: True


# "Großes UND": Sind ALLE Ausdrücke True?
expr_list = [1 != 2, 7 > 5, True, 'a' in 'banana', True]
res = True 
for expr in expr_list:
       if not expr:
           res = False      # wird nie wieder True
res

# stattdessen
all([1 != 2, 7 > 5, True, 'a' in 'banana', True])   # "großes UND"
# Ausgabe: True














