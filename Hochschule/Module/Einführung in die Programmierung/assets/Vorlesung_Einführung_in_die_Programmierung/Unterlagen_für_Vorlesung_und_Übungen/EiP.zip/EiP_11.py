"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


## Dictionaries anlegen, ändern und durchlaufen
###############################################################################

# Beispiel Wörterbuch: Typ Liste wegen int-Index ungeeignet

# Erstellen eines leeren Dictionaries
de2es = dict()      # Wörterbuch Deutsch -> Spanisch
# Alternative: de2es = {}
de2es
# Ausgabe: {}


# Hinzufügen von Schlüssel/Wert-Paaren
de2es['eins'] = 'uno'       # Schlüssel: 'eins', Wert: 'uno'
de2es
# Ausgabe: {'eins': 'uno'}  # Trennsymbol :

# Anzahl(!) der Schlüssel/Wert-Paare
len(de2es)
# Ausgabe: 1

# Achtung: Das ist nicht die 'Länge' i.S. von Bits oder Informationen
# denn auch ein Schlüssel/Wert-Paar kann viele Bits lang sein


# Erstellen eines Dictionaries mit mehreren Schlüssel/Wert-Paaren
de2es = {'eins': 'Uno', 'zwei': 'dos', 'drei': 'tres'}
de2es
# Ausgabe: {'eins': 'Uno', 'drei': 'tres', 'zwei': 'dos'}   # Reihenfolge nicht fix!

# Zugriff auf einen Wert mit Hilfe des Schlüssels
de2es['zwei']
# Ausgabe: 'dos'
de2es['vier']       # Ausnahme, falls Schlüssel nicht vorhanden
# Ausgabe: KeyError: 'vier'
    
# Prüfen, ob ein Schlüssel enthalten ist
'eins' in de2es
# Ausgabe: True
'vier' in de2es
# Ausgabe: False
'uno' in de2es      # es geht nur um die Schlüssel
# Ausgabe: False

# dict-Methode values liefert die Werte 
werte = de2es.values()
werte
type(werte)         # eigener Typ mit in-Operator 
'uno' in werte
# Ausgabe: True

# vorhandenen Entrag ändern 
de2es['eins'] = 'uno'
de2es
# Ausgabe: {'eins': 'uno', 'drei': 'tres', 'zwei': 'dos'}   # Reihenfolge nicht fix!



## Implementierung eines Histogramms
###############################################################################

# Erstellen eines Histogramms, das die Häufigkeit der Buchstaben zählt
def histogramm(s):
    """Erstellt ein Histogramm (dict) mit der Zuordnung von Buchstaben zu deren Häufigkeit
    
    s: String
    """
    d = dict()          # 
    for c in s:         # Muster "Zähler"
        if c not in d:  # das geht einigermaßen schnell
            d[c] = 1    # erstes Vorkommen
        else:
            d[c] += 1
    return d

h = histogramm('brontosaurus')
h
# Ausgabe: {'b': 1, 'r': 2, 'o': 2, 'n': 1, 't': 1, 'a': 1, 's': 2, 'u': 2}

# Ausnahmen vermeiden: dict-Methode get
h.get('a', 0)   # Angabe eines default-Wertes, falls Schlüssel nicht vorhanden
# Ausgabe: 1
h.get('z', 0)
# Ausgabe: 0

def histogramm_kurz(s):
    d = dict()         
    for c in s:        
        d[c] = 1 + d.get(c, 0)
    return d

h = histogramm_kurz('fachbereich informatik der hochschule trier')
h
# Ausgabe: {'f': 2, 'a': 2, ' ': 4, 'n': 1, ... }




## Iteration und inverse Suche
###############################################################################

# Schleife über ein Dictionary
def print_hist(h):
    for c in h:         # keine besondere Reihenfolge garantiert
        print(c, h[c])  # Schlüssel-Wert-Paare

h = histogramm('brontosaurus')
print_hist(h)
# Ausgabe:
# b 1
# r 2
# o 2
# n 1
# t 1
# a 1
# s 2
# u 2

# Sortieren der Schlüssel mit eingebauter Funktion
for key in sorted(h):   # siehe Vergleichsoperator auf Strings: a < b < c ....
    print(key, h[key])
# Ausgabe:
# a 1
# b 1
# n 1
# o 2
# r 2
# s 2
# t 1
# u 2

# Suche nach einem Wert, wenn Schlüssel unbekannt
def inverse_suche(d, w):
    for s in d:         # alle Schlüssel durchlaufen, so wie bei Listen
        if d[s] == w:
            return s    # liefert den zuerst(!) gefundenen Schlüssel für gegeben Wert 
    raise LookupError('Wert nicht im Dictionary enthalten')     # eigener Text möglich 

# Erfolgreiche inverse Suche
s = inverse_suche(h, 2) # 'Welcher Buchstabe kommt zweimal vor?'
s
# Ausgabe: 'r'          # aber es gibt noch andere...

# Erfolglose inverse Suche
s = inverse_suche(h, 3)  # löst Ausnahme aus
# Ausgabe: LookupError: Wert nicht im Dictionary enthalten


# Aber wir wollen alle(!) Buchstaben einer bestimmten Häufigkeit:
#   Schlüssel: Häufigkeit (int: unveränderbar -> ok)
#   Wert: Liste aller Buchstaben mit dieser Häufigkeit (list: veränderbar -> ok)

# Dictionary invertieren
def invertiere_dict(d):
    invers = dict()
    for schluessel in d:        # schluessel = Buchstabe  
        wert = d[schluessel]    # wert = dessen Häufigkeit
        if wert not in invers:  # Eintrag mit Rollentausch wert<->schluessel
            invers[wert] = [schluessel]     # zunächst als einelementige Liste
        else:                               # aber es könnte mehrere Buchstaben
            invers[wert].append(schluessel) # mit dieser Häufigkeit geben
    return invers

hist = histogramm('papagei')
hist
# Ausgabe: {'p': 2, 'a': 2, 'g': 1, 'e': 1, 'i': 1}

invers = invertiere_dict(hist)
invers
# Ausgabe: {2: ['p', 'a'], 1: ['g', 'e', 'i']}



## Rekursion mit Memoization
###############################################################################

# nochmal zur Wiederholung, siehe Kap. 6
def fibonacci(n):
    if n == 0:          # zwei Basisfälle
        return 0
    elif n == 1:
        return 1
    else:               # n >= 2
        print('Aufruf von fibonacci(', n-1, ') und fibonacci(', n-2, ')')
        return fibonacci(n-1) + fibonacci(n-2)

fibonacci(12)
# sehr große Redundanz bei nur 12 verschiedenen Werten:
#   nach den ersten 11 Zeilen sind bereits alle Werte bekannt


# Rekursion mit Memoization
bekannt = {0: 0, 1: 1}

def fibonacci(n):
    if n in bekannt:        # Schlüssel: Parameter n
        return bekannt[n]   # Wert: fibonacci(n)
    print('Aufruf von fibonacci(', n-1, ') und fibonacci(', n-2, ')')
    res = fibonacci(n-1) + fibonacci(n-2)
    bekannt[n] = res
    return res

fibonacci(12)
# 11 print-Zeilen 
# Ausgabe: 144



## Globale und lokale Variablen
###############################################################################

verbose = True          # global, da Zuweisung im Frame __main__

def Beispiel1():        # keine Zuweisung in der Funktion an verbose
    if verbose:         #   -> implizit global
        print('Beispiel1 wird ausgeführt')

Beispiel1()
# Ausgabe: 'Beispiel1 wird ausgeführt'

def Beispiel2():
    print(wurde_aufgerufen) # Fehler: Variable (auch in __main__) undefiniert 


wurde_aufgerufen = False

def Beispiel3():            #       
    print(wurde_aufgerufen) # Fehler: Zugriff auf lokale Var. vor Zuweisung
    wurde_aufgerufen = True # wg Zuweisung -> lokale Variable gleichen Namens

Beispiel3()
# Ausgabe: Fehler in Zeile 2 der Funktion (print)
#   UnboundLocalError: cannot access local variable 'wurde_aufgerufen' 
#   where it is not associated with a value


# Verwendung einer globalen Variable innerhalb einer Funktion
def Beispiel4():  
    global wurde_aufgerufen # Variable ist global, trotz lokaler Zuweisung      
    print(wurde_aufgerufen) # kein Fehler: Ausgabe False
    wurde_aufgerufen = True # Änderung der globalen Variable

print(wurde_aufgerufen)     #  vorher: False
Beispiel4()
print(wurde_aufgerufen)     #  nachher: True


# Änderung eines veränderbarenTyps ist ohne 'global' möglich
bekannt = {0: 0, 1: 1}      # dict: mutable 

# keine Zuweisung an bekannt (sondern an bekannt[2])
def Beispiel5():            
    bekannt[2] = 1          # -> bekannt ist implizit global
    
Beispiel5()
print(bekannt)              # Änderung des globalen Dictionaries
# Ausgabe: {0: 0, 1: 1, 2: 1}


# im Unterschied zu: 
bekannt = {0: 0, 1: 1}      # dict: mutable 
  
def Beispiel6():
    bekannt = {}            # wg Zuweisung -> lokale Variable gleichen Namens
    bekannt[2] = 100        # Änderung der lokalen Variable
    print(bekannt)
    
Beispiel6()
print(bekannt)              # keine Änderung des globalen Dictionaries
# Ausgabe: {0: 0, 1: 1}

