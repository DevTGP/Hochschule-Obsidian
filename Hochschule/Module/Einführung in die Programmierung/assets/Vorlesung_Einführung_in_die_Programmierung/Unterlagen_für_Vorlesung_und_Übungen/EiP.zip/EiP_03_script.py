"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

# 
# als Script ausf�hren
#


## Version 1
def zeige_text():                           
    print('Veronika, der Lenz ist da.')     
    print('Die Mädchen singen trallala.')   

def wiederhole_refrain():
    zeige_text() 
    zeige_text()

wiederhole_refrain()

# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.
# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.



# ## Version 2
# wiederhole_refrain()

# def zeige_text():                           
#     print('Veronika, der Lenz ist da.')     
#     print('Die Mädchen singen trallala.')   

# def wiederhole_refrain():
#     zeige_text() 
#     zeige_text()

# Ausgabe: NameError: name 'wiederhole_refrain' is not defined



# ## Version 3
# def wiederhole_refrain():
#     zeige_text() 
#     zeige_text()

# def zeige_text():                           
#     print('Veronika, der Lenz ist da.')     
#     print('Die Mädchen singen trallala.')   

# wiederhole_refrain()

# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.
# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.

