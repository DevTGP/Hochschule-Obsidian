"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

## Weitere Operatoren: Floor und Modulo
###############################################################################

# Floor-Division (//) teilt zwei Zahlen und gibt den abgerundeten Integerwert zurück
minuten = 105
stunden = minuten // 60
print(stunden)
# Ausgabe: 1

# die Nachkommastellen werden stets abgeschnitten
99/100
# Ausgabe: 0.99
99//100
# Ausgabe: 0

# Modulo (%) gibt den Rest der Division zurück
rest = minuten % 60
print(rest)
# Ausgabe: 45

# Teilbarkeit testen: x%y ist 0 gdw x durch y teilbar
80 % 3 
# Ausgabe: 2
80 % 4
# Ausgabe: 0

# letze Ziffern extrahieren
x = 123456789
x % 10
# Ausgabe: 9
x % 100
# Ausgabe: 89
x % 100000
# Ausgabe: 56789



## Boolesche Ausdrücke und Operatoren 
###############################################################################

# Boolesche Ausdrücke durch Vergleich
5 == 5
# Ausgabe: True
5 == 6
# Ausgabe: False
# Typüberprüfung für boolesche Werte
type(True)
# Ausgabe: <class 'bool'>
type(False)
# Ausgabe: <class 'bool'>
type(5 == 6)
# Ausgabe: <class 'bool'>

# Vergleichsoperatoren
x = 7           # Zuweisung!
y = 10
x != y          # ungleich
# Ausgabe: True
x < y           # echt kleiner
# Ausgabe: True
x > y           # echt größer
# Ausgabe: False
x <= x          # echt kleiner oder gleich
# Ausgabe: True
x >= y          # echt größer oder gleich
# Ausgabe: False

# Logische Operatoren
x < y and x > 5     # genau dann True wenn es beide Seiten auch sind
# Ausgabe: True
x < y and x > 8     
# Ausgabe: False
x < y or x > 8      # genau dann True wenn es mind. eine Seite ist
# Ausgabe: True
x < x or x > 8      
# Ausgabe: False
not x > 5           # Verneinung True -> False und umgekehrt
# Ausgabe: False
not True
# Ausgabe: False
not False
# Ausgabe: True
not true            # Groß-/Kleinschreibung wichtig!
# Ausgabe: NameError: name 'true' is not defined
z = 6
z % 2 == 0 and z % 3 == 0
# Ausgabe: True

# numerische und Boolesche Ausdrücke können in Python gemischt werden
# manchmal nützlich, wenn man genau weiß, was da passiert
# oft aber eine Fehlerquelle! -> vermeiden
42 and True         
# Ausgabe: True


## Bedingte Anweisungen
###############################################################################

# Bedingte Anweisung (if)
x = 5
if x > 0:                   # Header: Schlüsselwort if, dann eine Bedingung gefolgt von :
    print('x ist positiv')  # Body: beliebig viele eingerückte Anweisungen
                            # wird ausgeführt falls Bedingung True ergibt
# bei False geht es direkt hier weiter, ohne Ausführung des Bodys 
# Ausgabe: x ist positiv

# Body muss mind. eine Anweisung enhalten
if x < 0:                   
    pass       # tut nichts, aber kann als Platzhalter dienen 

# Alternative: if-else
if x % 2 == 0:
    print('x ist gerade')   # nur wenn Bedingung True (entweder)
else:                       # Schlüsselwort und :
    print('x ist ungerade') # nur wenn Bedingung False (oder)
# Ausgabe: x ist ungerade

# Verkettung von mehreren Bedingungen: elif
if x < y:                           # Prüfung von oben nach unten
    print('x ist kleiner als y')
elif x > y:                         # Bed wird nur geprüft, falls x < y False
    print('x ist größer als y')     
else:    
    print('x und y sind gleich')    # wird ausgeführt, falls alle Bed False
# Ausgabe: x ist kleiner als y

# weiteres Beispiel, ohne else am Schluss
auswahl = 'c'
if auswahl == 'a':
    print(1)
elif auswahl == 'b':
    print(2)
elif auswahl == 'c':
    print(3)

# Verschachtelte Bedingungen: Einrückungen sind wichtig!
if x < y:
    print('x ist kleiner als y')
else:
    if x > y:
        print('x ist größer als y')
    else:
        print('x und y sind gleich')
# ergibt gleiche Struktur wie oben, aber unübersichtlicher -> besser vermeiden
# Ausgabe: x ist kleiner als y

# Vereinfachung verschachtelter Bedingungen durch log. Operatoren
if 0 < x:
    if x < 10:
        print('x ist eine positive einstellige Zahl.')
# 
if 0 < x and x < 10:
    print('x ist eine positive einstellige Zahl.')
# Ausgabe: x ist eine positive einstellige Zahl.




##  Rekursion
###############################################################################

# Erstes Beispiel
def countdown(n):
    if n == 0:          # falls 0 erreicht wird
        print('Bumm!')  # gibt es keinen weiteren Selbstaufruf mehr
    else:
        print(n)        # Ausgabe des aktuellen Paramenters
        countdown(n-1)  # aus Parameter n wird Argument n-1

countdown(3)
# Ausgabe:
# 3
# 2
# 1
# Bumm!


# Rekursive Funktion, die einen String n-mal ausgibt
def print_n(s, n):
    if n <= 0:
        return          # zurück an die aufrufende Stelle
    print(s)
    print_n(s, n-1)     # es fehlen noch n-1 Ausgaben

print_n('Hallo', 3)
# Ausgabe:
# Hallo
# Hallo
# Hallo

print_n('Einführung in die Programmierung ist wichtig!', 100)



## Endlose Rekursion
###############################################################################

def rekursiere():
    rekursiere()        # endlos, weil kein Basisfall vorhanden

rekursiere()
# Ausgabe: <Traceback mit 1000 Frames>
# Ausgabe: RecursionError: maximum recursion depth exceeded

countdown(-1)           # endlos, weil Basisfall nie erreicht wird
# Ausgabe: <Traceback mit 1000 Frames>
# Ausgabe: RecursionError: maximum recursion depth exceeded



## Tastatureingaben
###############################################################################

# Tastatureingabe wir mit <RETURN> abgeschlossen
eingabe = input()       # eingebaute Funktion
eingabe

# mit Eingabeaufforderung
name = input('Wie heißen Sie?\n') # mit Sonderzeichen für Zeilenumbruch
# Text tippen
name

# erwartete und unerwartete Eingaben
eingabeaufforderung = 'Wie hoch ist die Fluggeschwindigkeit einer unbeladenen Schwalbe?\n'
geschwindigkeit = input(eingabeaufforderung)
# Text eintippen, zB 42
int(geschwindigkeit)    # von str nach int, damit wir damit weiter rechnen können 
# Ausgabe: 42

geschwindigkeit = input(eingabeaufforderung)
# Text eintippen, zB 42.7 oder Meinen Sie eine afrikanische oder eine europäische Schwalbe?
int(geschwindigkeit)
# Ausgabe: ValueError: invalid literal for int() with base 10


# und noch ein Hinweis zur Fehlersuche:  
import math
signalleistung = 9
rauschleistung = 10
verhaeltnis = signalleistung // rauschleistung
dezibel = 10 * math.log10(verhaeltnis)
print(dezibel)

# Ausgabe: ...line 5
# Ausgabe: dezibel = 10 * math.log10(verhaeltnis)
# Ausgabe: ValueError: math domain error

# In Zeile 5 hat Python des Problem bemerkt
# aber die Ursache liegt in Zeile 4 bei // 





