"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

## Zuweisungen von Werten an Variablen
###############################################################################

meldung
# Ausgabe: NameError: name 'meldung' is not defined

meldung = 'Und jetzt etwas ganz anderes'
# Ausgabe: keine, aber es gibt einen Effekt!
meldung


# Weitere Variablen 
n = 17
pi = 3.1415926535897932     # zwangsläufig ungenau!


# Anzeige der aktuellen Zuordnung von Namen zu Werten im Variable Explorer
n = 71
n

r = 10.2        # Kreisradius
u = 2 * pi * r  # Kreisumfang, ungenau wegen pi
print(u)

# links von = muss eine Variable stehen!
stunden = 24
minuten = stunden * 60      # richtig
stunden * 60 = minuten      # falsch!
# Ausgabe: SyntaxError: cannot assign to expression here



# Zurücksetzen der Console

## Variablennamen
###############################################################################

76posaunen = 'Große Parade'     # beginnt mit einer Ziffer
# Ausgabe: SyntaxError: invalid decimal literal

mehr@ = 1000000                 # Symbol @ nicht erlaubt
# Ausgabe: SyntaxError: invalid syntax

else = 'Fortschrittliche Theoretische Zymologie'    # Schlüsselwort
# Ausgabe: SyntaxError: invalid syntax


Else = 'Fortschrittliche Theoretische Zymologie'    # kein Schlüsselwort
# Groß- und Kleinschreibung sind relevant!


## Ausdrücke und Anweisungen
###############################################################################

# Verwendung von Variablen in Ausdrücken
n + 25
# Ausgabe: 96

r = 5           # Zuweisung: anderer Kreisradius
2 * pi * r      # Ausdruck: so wie oben
# Ausgabe: 31.4159...



## Interaktiver Modus versus Skriptmodus
###############################################################################

# Starten eines Programms im Skriptmodus
# IDE: Run im Kontextmenu auf dem Dateinamen
# Shell: 'python <Dateiname>



## Rangfolge mathematischer Operatoren
###############################################################################

# Rangfolge der Operatoren in mathematischen Ausdrücken
2 - 1 * 3           # wie 2 - (1 * 3) weil * vor -
# Ausgabe: -1
2 * 3 - 1           # weil * vor -, und nicht wegen Leserichtung
# Ausgabe: 5
2 * (3 - 1)         # Klammern setzen, wenn wir etwas anderes wollen
# Ausgabe: 4

1 + 2**3            # ** vor +
# Ausgabe: 9
(1 + 2)**3          # Klammern vor **
# Ausgabe: 27
2 * 3**2            # ** vor *
# Ausgabe: 18
1 + 1**5 - 2        # ** vor + vor -
# Ausgabe: 0
(1 + 1)**(5 - 2)    # Klammern vor **
# Ausgabe: 8
(1 + 1)**5 - 2      # Klammern vor ** vor -
# Ausgabe: 30

# bei gleichem Rang von links nach rechts
grad = 90
grad / 2 * pi
# Ausgabe: 141.371...
(grad / 2) * pi     # Klammern unnötig
# Ausgabe: 141.371...
grad / (2 * pi)     # das ist etwas anderes
# Ausgabe: 14.323...
grad / 2 / pi       # so geht's auch, aber schlechter lesbar
# Ausgabe: 14.323...




## String-Operationen: Konkatenation und Wiederholung
###############################################################################

erster = 'donner'
zweiter = 'gurgler'
erster + zweiter            # Konkatenation = Hintereinanderschreibung
# Ausgabe: 'donnergurgler'

'Spam' * 3                  # dreifache Wiederholung: 'Spam'+'Spam'+'Spam'
# Ausgabe: 'SpamSpamSpam'   

Spam = 5        # der Typ ist wichtig!
Spam * 3
#Ausgabe: 15

# wie bei mathematischen Ausdrücken gilt bei Strings auch * vor +
erster + 3 * zweiter        # * zuerst
# Ausgabe: 'donnergurglergurglergurgler'
erster + (3 * zweiter)      # Klammern unnötig
# Ausgabe: 'donnergurglergurglergurgler'
erster * 3 + zweiter        # * zuerst
# Ausgabe: 'donnerdonnerdonnergurgler'
erster * (3 + zweiter)
# Ausgabe: TypeError        # warum?




## Kommentare im Code
###############################################################################

# beginnen stets mit '#' und gegen bis zum Zeilenende

# Berechnen, wie viel Prozent der aktuellen Stunde abgelaufen sind 
minute = 30                         # Beispielwert
prozentsatz = (minute * 100) / 60
print(prozentsatz)
# Ausgabe: 50.0

# sinnloser Kommentar:
v = 5       # v den Wert 5 zuweisen
# besserer Kommentar mit Zusatzinformation:
v = 5       # Geschwindigkeit in Metern pro Sekunde


x =30
y=x*10/ 6








