"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""


# interaktiver Modus

# Funktionsammlung

import math            

def polylinie(t, n, laenge, winkel):
    """Zeichnet n zusammenhängende Liniensegmente. 
    t: Turtle-Objekt
    n: Anzahl der Liniensegmente
    laenge: Länge jedes einzelnen Segments in Pixel
    winkel: Winkel zwischen den Segmenten in Grad
    """
    for i in range(n):
        t.fd(laenge)
        t.lt(winkel)    

def polygon(t, n, laenge):
    """Zeichnet geschlossenen Streckenzug mit n Ecken. 
    t: Turtle-Objekt
    n: Anzahl der Ecken
    laenge: Länge jedes einzelnen Segments in Pixel
    """
    winkel = 360.0 / n              # Winkel wird so gewählt, dass Streckenzug geschlossen
    polylinie(t, n, laenge, winkel) # Anzahl Ecken = Anzahl Segmente

def bogen(t, r, winkel):
    """Zeichnet Kreisbogen mit Radius r und Kreisausschnitt gemäß winkel.
    t: Turtle-Objekt
    r: Radius in Pixel
    winkel: Kreisausschnitt in Grad
    """
    bogen_laenge = 2 * math.pi * r * winkel / 360   
    n = int(bogen_laenge / 3) + 1                   # etwa 3 Pixel pro Segment
    schritt_laenge = bogen_laenge / n
    schritt_winkel = float(winkel) / n
    polylinie(t, n, schritt_laenge, schritt_winkel) # Bogen entsteht durch viele Liniensegmente

def kreis(t, r):
    """Zeichnet Kreis mit Radius r.
    t: Turtle-Objekt
    r: Radius in Pixel
    """
    bogen(t, r, 360)

help(bogen)
help(polylinie)

