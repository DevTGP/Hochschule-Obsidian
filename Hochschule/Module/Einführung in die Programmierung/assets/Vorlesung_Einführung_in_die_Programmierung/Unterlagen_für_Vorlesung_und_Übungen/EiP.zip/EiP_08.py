"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

## Strings und Zugriff per Index
###############################################################################

frucht = 'banane'
zeichen = frucht[1]     # Zugriff auf ein Zeichen per Index und Klammeroperator
zeichen
# Ausgabe: 'a'          # nicht 'b' !

zeichen = frucht[0]     # denn es geht in Python immer bei 0 los
zeichen
# Ausgabe: 'b'

i = 2                   # typischer Name für eine Indexvariable
print(frucht[i])
# Ausgabe: 'n'
i = i + 1               # Inkrement
print(frucht[i])
# Ausgabe: 'a'

laenge = len(frucht)    # eingebaute Funktion für die Länge eines Strings
laenge
# Ausgabe: 6

letzter = frucht[laenge]    # so nicht
# Ausgabe: IndexError: string Index out of range

# es geht bei Null los:
#   Indexbereich 0, 1, 2, ... , len(frucht)-1

# Zugriff auf das letzte Zeichen eines Strings
letzter = frucht[laenge - 1]
letzter
# Ausgabe: 'e'

# Alternative: 
letzter = frucht[-1]    # negativer Index zählt von rechts
letzter
# Ausgabe: 'e'
vorletzter = frucht[-2]
vorletzter
# Ausgabe: 'n'

# negativer Index beginnt bei -1 und nicht bei -0 (weil -0 == 0)


# Traversierung eines Strings mit while-Schleife
index = 0
while index < len(frucht):
    zeichen = frucht[index]
    print(zeichen)
    index = index + 1
# Ausgabe:
# b
# a
# n
# a
# n
# e

# Schreiben Sie als Übung eine Funktion, die einen String als Argument erwartet 
# und die Zeichen rückwärts anzeigt – eines pro Zeile.

# viel besser mit for-Schleife, denn Anzahl Iterationen steht vorher schon fest!
for zeichen in frucht:  # kommt sogar ohne expliziten Index aus
    print(zeichen)
# Ausgabe:
# b
# a
# n
# a
# n
# e

# Beispiel mit Präfixen und Suffixen
praefixe = 'JKLMNOPQ'
suffix = 'ack'
for zeichen in praefixe:
    if zeichen == 'O' or zeichen == 'Q':    # Ausnahmen
        print(zeichen + 'u' + suffix)       # + als String-Operation
    else:
        print(zeichen + suffix)
# Ausgabe:
# Jack
# Kack
# Lack
# Mack
# Nack
# Ouack
# Pack
# Quack




## Slicing und Unveränderbarkeit
###############################################################################

# Lesender Zugriff auf Teile eines Strings: Klammeroperator und :
s = 'Monty Python'
s[0:5]              # von Index 0 (einschließlich) bis Index 5 (ausschließlich!)
# Ausgabe: 'Monty'
s[6:12]             # Position 12 gibt es in s überhaupt nicht!
# Ausgabe: 'Python'
s[:5]               # ohne Startindex -> immer von Anfang an
# Ausgabe: 'Monty'
s[6:]               # ohne Endindex -> immer bis zum Schluss
# Ausgabe: 'Python'
s[:]                # weder noch -> von Anfang bis Ende
# Ausgabe: 'Monty Python'

frucht = 'banane'
frucht[4:1]         # da bleibt nichts übrig
# Ausgabe: ''       # deshalb leere Zeichenkette 
frucht[3:3]         # von 3 (einschließlich) bis 3 (ausschließlich!)
# Ausgabe: ''

# Strings sind unveränderbar
gruss = 'Hallo, Welt!'
gruss[0] = 'J'          # eine Zeichenfolge können wir nicht ändern!
# Ausgabe: TypeError: 'str' object does not support item assignment
# sondern wir müssen uns bei Bedarf immer eine neue bauen
neuer_gruss = 'J' + gruss[1:]
neuer_gruss
# Ausgabe: 'Jallo, Welt!'

# jetzt gibt es beide Strings unabhängig voneinander
id(gruss) != id(neuer_gruss)
# Ausgabe: True





## Suchen und Zählen
###############################################################################

# Suchen eines Zeichens in einem String
def suche(wort, zeichen):
    index = 0
    while index < len(wort):
        if wort[index] == zeichen:
            return index            # Funktion wird hier beendet, mit Rückgabewert
        index = index + 1           # Inkrement
    return -1                       # zeichen kommt nicht vor

suche('banane', 'a')
# Ausgabe: 1
suche('banane', 'z')
# Ausgabe: -1
suche('', 'a')
# Ausgabe: -1
suche('banane', '')
# Ausgabe: -1

# geht das auch mit einer for-Schleife?
#   for symbol in wort:
#       ...

# Passen Sie als Übung die Fkt. suche so an, dass sie einen dritten Parameter 
# erwartet – den Index, ab dem die Suche in wort erst beginnen soll.


# Zählen, wie oft ein Zeichen in einem String vorkommt
wort = 'banane'
anzahl = 0  
for zeichen in wort:            # kein vorzeitiges Schleifenende
    if zeichen == 'a':
        anzahl = anzahl + 1
anzahl
# Ausgabe: 2
#


# Verpacken Sie diesen Code zur Übung in eine Funktion mit dem Namen anzahl
# und generalisieren Sie so, dass sie den String und das Zeichen als Argumente erwartet.

# Schreiben Sie die Funktion so um, dass der String nicht durchlaufen wird, 
# sondern die Version von suche aus dem vorherigen Abschnitt mit drei Parametern zum Einsatz kommt.




## String-Methoden und Operatoren
###############################################################################

# Umwandlung in Großbuchstaben per String-Methode 
wort = 'banana'
neues_wort = wort.upper()   # Aufruf der Methode upper() für wort mit . (statt upper(wort))
neues_wort
# Ausgabe: 'BANANA'

# Verwendung der String-Methode find()
index = wort.find('a')
index
# Ausgabe: 1
index = wort.find('na', 3)      # Startindex als optionales Argument: ab Index 3
index
# Ausgabe: 4
name = 'bob'                    # Endindex als weiteres optinales Argument:
name.find('b', 1, 2)            # bis Index 2 (ausschließlich)
# Ausgabe: -1
name[1:2].find('b')             # Alternative

# Verwendung des in-Operators
'a' in 'banana'
# Ausgabe: True
'anna' in 'banana'
# Ausgabe: False

# relationale Operatoren auf Strings
'a' < 'c'
# Ausgabe: True
'ab' < 'ac'         # lexikographische Ordnung: 2. Stelle bei gleicher 1. Stelle usw.
# Ausgabe: True
'Z' < 'a'           # aber alle Großbuchtsbaben kommen vor allen Kleinbuchstaben!
# Ausgabe: True

# Funktion zum Vergleichen von Wörtern
wort = 'Pinienkern'
if wort < 'banane':         
    print('Ihr Wort ' + wort + ' kommt im Alphabet vor banane.')
elif wort > 'banane':
    print('Ihr Wort ' + wort + ' kommt im Alphabet nach banane.')
else:
    print('Alles klar, Bananen.')
# Ausgabe: 'Ihr Wort Pinienkern kommt im Alphabet vor banane.'
# weil 'P' < 'b'

# gute Lesbarkeit! 
def in_beiden(wort1, wort2):
    for zeichen in wort1:       # für jedes Zeichen in wort1
        if zeichen in wort2:    #   falls es in wort2 vorkommt
            print(zeichen)      #       gebe es aus 

in_beiden('apfel', 'orange')
in_beiden('astronomer', 'moonstarer')




## Fehlersuche
###############################################################################

# Funktion, die überprüft, ob ein Wort die Umkehrung eines anderen ist
def ist_umkehrung(wort1, wort2):
    if len(wort1) != len(wort2):    # Wächter
        return False
    # ab hier haben beide Worte die gleiche Länge
    i = 0                   # Index für wort1 von links nach rechts
    j = len(wort2)          # Index für wort2 von rechts nach links     
    while j >= 0:
        if wort1[i] != wort2[j]:   # keine Übereinstimmung 
            return False
        i = i + 1           # Index für nöchstes Zeichen in wort1
        j = j - 1           # und in wort 2
    return True

print(ist_umkehrung('gras', 'sarg'))
# Ausgabe: IndexError: string index out of range

# wo ist der Fehler?

# print an geeigneter Stelle einbauen: Fehlermeldung war bei 2. if
def ist_umkehrung(wort1, wort2):
    if len(wort1) != len(wort2):    
        return False
    i = 0       
    j = len(wort2)    
    while j >= 0:
        print(i,j)                  # NEU: scaffolding
        if wort1[i] != wort2[j]:  
            return False
        i = i + 1      
        j = j - 1      
    return True

print(ist_umkehrung('gras', 'sarg'))
# Ausgabe 0 4
# aber j darf nicht 4 sein!

# was sollten wir ändern?

# und es gibt noch einen weiteren Fehler....

# korrekte Version
def ist_umkehrung(wort1, wort2):
    if len(wort1) != len(wort2):    
        return False
    i = 0       
    j = len(wort2) - 1    
    while j > 0:
        if wort1[i] != wort2[j]:  
            return False
        i = i + 1      
        j = j - 1      
    return True

ist_umkehrung('abc','cba')
ist_umkehrung('ab','bab')
ist_umkehrung('otto','otto')
ist_umkehrung('drehmalamherd','drehmalamherd')
ist_umkehrung('einegüldnegutetugendlügenie', 'einegüldnegutetugendlügenie')


