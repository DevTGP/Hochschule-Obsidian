"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

## Rückgabewerte 
###############################################################################

# Funktion zur Berechnung der Fläche eines Kreises
import math

def flaeche(radius):
    a = math.pi * radius**2 
    return a    # kehre sofort zum Aufruf zurück und verwende 
                # den nachfolgenden Ausdruck als Rückgabewert, hier a

print(flaeche(5))
# Ausgabe: 78.539...

# oder kürzer ohne temporäre Variable:
def flaeche(radius):
    return math.pi * radius**2  # zuerst wird der Ausdruck ausgewertet
                                # dann erfolgt der Rücksprung

# Funktion zur Berechnung des absoluten Werts, mit mehreren returns
def absoluter_wert(x):
    if x < 0:
        return -x       # entferne negatives Vorzeigen
    else:               # d.h. x > 0 oder x = 0
        return x        # nichts zu tun, Rückgabe von unverändertem x 

absoluter_wert(-10)
# Ausgabe: 10
absoluter_wert(10)
# Ausgabe: 10

# fehlerhaft!
def absoluter_wert(x):
    if x < 0:
        return -x
        print('Diese Ausgabe erscheint nie!')   # toter Code
    if x > 0:  
        return x
    # die Funktion wird in dieser Zeile ohne Rückgabewert beendet, falls x = 0

absoluter_wert(-10)
# Ausgabe: 10
absoluter_wert(0)
# keine Ausgabe
print(absoluter_wert(0))
# Ausgabe: None
# das ist problematisch, wenn an der aufrufenden Stelle stets ein Wert erwartet wird

# siehe auch eingebaute Funktion abs()

# Funktion zum Vergleichen von zwei Zahlen
def vergleiche(x, y):
    if x > y:
        return 1
    elif x == y:
        return 0
    else:
        return -1

vergleiche(10, 5)
# Ausgabe: 1
vergleiche(1, 1.0)
# Ausgabe: 0
vergleiche(2, 5)
# Ausgabe: -1




## Inkrementelle Entwicklung
###############################################################################

# Gesucht: Entfernung zwischen zwei Punkten in der Ebene nach Pythagoras
# Vorüberlegung
#   Koordinaten des 1. Punkts: (x1, y1)  -> Parameter 
#   Koordinaten des 2. Punkts: (x2, y2)  -> Parameter
#   Ergebnis float  -> Rückgabewert
# führt zu Version 1:
def entfernung(x1, y1, x2, y2):
    return 0.0

# wichtig bei Testdaten: Sollergebnis unabhängig vom Code vorher bestimmen!
entfernung(1, 2, 4, 6)  
# Ausgabe: 0.0
  
# Zwischenwerte berechnen, speichern und prüfen, führt zu Version 2:
def entfernung(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    print('dx ist', dx)
    print('dy ist', dy)
    return 0.0

entfernung(1, 2, 4, 6)      # alles Ok? 
# Ausgabe: 0.0

# nächster Zwischenschritt führt zu Version 3:
def entfernung(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    quadratsumme = dx**2 + dy**2
    print('Quadratsumme ist: ', quadratsumme)
    return 0.0

entfernung(1, 2, 4, 6)      # stimmt's noch?
# Ausgabe: 0.0

# Letzter Schritt, ggf. Kommnetare und Docstring ergänzen:
def entfernung(x1, y1, x2, y2):
    dx = x2 - x1        # Abstand in x-Richtung
    dy = y2 - y1        # Abstand in y-Richtung
    quadratsumme = dx**2 + dy**2
    ergebnis = math.sqrt(quadratsumme)
    return ergebnis

print(entfernung(1, 2, 4, 6))
# Ausgabe: 5.0

# je mehr verschiedene Testfälle inkl. Sollergebnis die Entwicklung begleiten, desto besser



## Komposition und Boolesche Funktionen
###############################################################################

# Funktionskomposition: Berechnung der Kreisfläche bei zwei gegebenen Punkten
# unter Verwendung bereits vorhandener Funktionen
def kreis_flaeche(xk, yk, xp, yp):
    """Berechnet Kreisfläche bei zwei gegebenen Punkten.
    (xk, yk): Koordinaten des Kreismittelpunkts
    (xp, yp): Koordinaten eines Punktes auf dem Kreisumfang
    """
    radius = entfernung(xk, yk, xp, yp)
    ergebnis = flaeche(radius)
    return ergebnis

# oder ganz kurz?
# hier sieht man zwar die Komposition der beiden Funktionen gut
# aber es ist nicht ablesbar, dass entfernung einen radius liefert
def kreis_flaeche(xk, yk, xp, yp):
    """Berechnet Kreisfläche bei zwei gegebenen Punkten.
    (xk, yk): Koordinaten des Kreismittelpunkts
    (xp, yp): Koordinaten eines Punktes auf dem Kreisumfang
    """
    return flaeche(entfernung(xk, yk, xp, yp))

# also besser so:
def kreis_flaeche(xk, yk, xp, yp):
    """Berechnet Kreisfläche bei zwei gegebenen Punkten.
    (xk, yk): Koordinaten des Kreismittelpunkts
    (xp, yp): Koordinaten eines Punktes auf dem Kreisumfang
    """
    radius = entfernung(xk, yk, xp, yp)
    return flaeche(radius)

print(kreis_flaeche(0, 0, 3, 4))
# Ausgabe: 78.539...

# Boolesche Funktion zur Überprüfung, ob eine Zahl durch eine andere teilbar ist
def ist_teilbar(x, y):      # Name sprechend gewählt: Antwort ist True oder False
    if x % y == 0:
        return True         # verdächtige Struktur...
    else:
        return False

# Vereinfachung, denn == liefert bereits einen Wahrheitswert 
def ist_teilbar(x, y):
    return x % y == 0

print(ist_teilbar(6, 3))
# Ausgabe: True
print(ist_teilbar(7, 3))
# Ausgabe: False

x = 6
y = 5
# Verwendung: nicht so
if ist_teilbar(x, y) == True:       # Vergleich ist unnötig
    print('x ist teilbar durch y')
# sondern so:    
if ist_teilbar(x, y):
    print('x ist teilbar durch y')



## Mehr Rekursion, jetzt mit Rückgabewert
###############################################################################

# Definition der Fakultätsfunktion (Funktionssymbol !)
# siehe https://de.wikipedia.org/wiki/Fakultät_(Mathematik)
# 
# 0! = 1
# n! = n*(n-1)! für n>= 1
# 
# Bsp.: 4! = 4*3! = 4*3*2! = 4*3*2*1! = 4*3*2*1*0! = 4*3*2*1*1 = 24 

# Berechnung der Fakultät durch rekursive Funktion
def fakultaet(n):
    if n == 0:                          # Basisfall
        return 1
    else:                               # n >= 1
        ergebnis = n * fakultaet(n-1)   # inkl. Selbstaufruf mit kleinerem Argument
        return ergebnis

print(fakultaet(5))
# Ausgabe: 120



## Ein Beispiel mit viel Vertrauen
###############################################################################

# Definition der Fibonacci-Funktion
# https://de.wikipedia.org/wiki/Fibonacci-Folge
# 
# fib(0) = 0
# fib(1) = 1                                # zwei Startwerte notwendig
# fib(n) = fib(n-1) + fib(n-2) für n>=2     # weil hier n-2 auftaucht
# 
# Bsp.: fib(4) = fib(3) + fib(2) = (fib(2) + fib(1)) + (fib(1) + fib(0))
# = ((fib(1) + fib(0)) + fib(1)) + (fib(1) + fib(0)) = ((1+0)+1)+(1+0) = 3

# rekursive Berechnung gemäß Definition
def fibonacci(n):
    if n == 0:          # zwei Basisfälle
        return 0
    elif n == 1:
        return 1
    else:               # n >= 2
        return fibonacci(n-1) + fibonacci(n-2) # zwei(!) rekursive Aufrufe

# den Programmablauf manuell zu verfolgen ist schon bei relativ kleinem n nicht mehr möglich
# -> es geht nur mit Vertrauenvorschuss

fibonacci(4)
# Ausgabe: 3
fibonacci(12)   # hier gibt es bereits mehr als 128 rekursive Aufrufe
# Ausgabe: 144




## Typprüfung
###############################################################################

# kein Docstring in der Funktion fakultaet
fakultaet(1.5)
# Ausgabe: RecursionError: maximum recursion depth exceeded
# denn fakultaet(1.5) -> fakultaet(0.5) -> fakultaet(-0.5) -> fakultaet(-1.5) -> ...


# Wächter: Typprüfung zu Beginn einer rekursiven Funktion
def fakultaet_erweitert(n):
    if not isinstance(n, int):                                  # Wächter 1
        print('Fakultät ist nur für ganze Zahlen definiert.')
        return None
    elif n < 0:                                                 # Wächter 2
        print('Fakultät ist nicht für negative ganze Zahlen definiert.')
        return None
    elif n == 0:            # ab hier wie vorher
        return 1
    else:
        return n * fakultaet_erweitert(n-1)

fakultaet_erweitert(5)
# Ausgabe: 120

fakultaet_erweitert(-2)
# Ausgabe: Fakultät ist nicht für negative ganze Zahlen definiert.
# Ausgabe: None

fakultaet_erweitert('fred')
# Ausgabe: Fakultät ist nur für ganze Zahlen definiert.
# Ausgabe: None


# effizientere Variante: Wächter werden nur einmal aktiviert
def fakultaet_erweitert(n):
    if not isinstance(n, int):                                  # Wächter 1
        print('Fakultät ist nur für ganze Zahlen definiert.')
        return None
    elif n < 0:                                                 # Wächter 2
        print('Fakultät ist nicht für negative ganze Zahlen definiert.')
        return None
    else:
        fakultaet(n)        # weiter rekusiv ohne Wächter

fakultaet_erweitert(5)
# Ausgabe: 120


# noch effizienter: Vorbedingung dokumentieren
# -> Verantwortung geht auf den Aufrufenden über  :-)
def fakultaet(n):
    """Berechnet n!
    n: int
    """
    if n == 0:
        return 1
    else:                               # n >= 1
        return n * fakultaet(n-1)




