"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# auf MacOS ist die Ausführung ggf über die Konsole notwendig
#   (Problem beim Aufruf von Turtle aus einer IDE heraus)
#


import turtle           
bob = turtle.Turtle()   


# Generalisierung: Verallgemeinerung einer Funktion
def quadrat(t, laenge): # zB durch einen weiteren Parameter
    for i in range(4):  
        t.fd(laenge)    # laenge ist jetzt variabel
        t.lt(90)

# der Aufruf muss angepasst werden!
# quadrat(bob)
# Ausgabe: TypeError: quadrat() missing 1 required positional argument: 'laenge'

# gleiches Ergebnis wie vorher erhalten wir jetzt so:
# quadrat(bob, 100)


quadrat(bob, 2)
quadrat(bob, 4)
quadrat(bob, 8)
quadrat(bob, 16)
quadrat(bob, 32)
quadrat(bob, 64)
quadrat(bob, 128)
quadrat(bob, 256)       # hier könnte man wieder an eine for-Anweisung denken...

turtle.mainloop()       # warte auf Eingaben (nur Fenster schließen möglich)



