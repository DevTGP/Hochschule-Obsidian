"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

## Zuweisungen und Speicherorte
###############################################################################

x = 5
# wir können das Zustandsdiagramm mit der eingebauten Funktion id() prüfen
id(5)       # Identität (=Speicherort) des Wertes 5
id(x)       # x verweist auf den Speicherort der 5

x = 7       # Variable Explorer: zugordneter Wert ändert sich
id(7)       # die 7 hat einen anderen(!) Speicherort
id(x)       # x verweist nun auf den Speicherort der 7

# die ID von x (Variable) ändert sich je nach zugeordnetem Wert
# die ID des Wertes 7 (Konstante) ändert sich nicht


# Beispiel für mehrfache Zuweisung
a = 5
b = a           # a und b verweisen auf dieselbe(!) 5
id(a) == id(b)  # Zustandsdiagramm: beide Pfeile auf die 5
# Ausgabe: True
a = 3           # a ändert sich, aber b bleibt gleich
b
# Ausgabe 5



## Initialisierung und Aktualisierung
###############################################################################

x = 0
y = 0           # Zustandsdiagramm: beide Pfeile auf die 0
x = x + 1       # erst wird x+1 zu 1 ausgewertet, dann die Zuweisung x -> 1
x
# Ausgabe: 1

# nochmal mit id()
id(0)               # Speicherort des Wertes 0
x = 0               # x verweist nun dorthin
id(x + 1) == id(1)  # Speicherort des Wertes 1
x = x + 1           # x verweist danach auf 1           
id(x)               




## while-Schleife
###############################################################################

# Countdown-Funktion mit while-Schleife
def countdown(n):
    while n > 0:    # Header: "solange" die Bedingung gilt
        print(n)    # Body: eingerückte Anweisungen
        n = n - 1
    print('Bumm!')

countdown(3)
# Ausgabe:
# 3
# 2
# 1
# Bumm!
countdown(1)
countdown(0)

# countdown: n-viele Iterationen, falls n aus N
# und sonst?
countdown(-2)
countdown(1.01)




## weitere Beispiele
###############################################################################

# Collatz-Problem, siehe https://de.wikipedia.org/wiki/Collatz-Problem
# Offene Frage: Terminiert die Schleife für alle Eingaben n aus den nat. Zahlen N? 
def sequenz(n):
    while n != 1:           # Ende bei 1
        print(n)
        if n % 2 == 0:
            n = n // 2      # gerade Zahlen werden halbiert
        else:  
            n = 3*n + 1     # aus ungerade wird größere gerade Zahl
    print(1)

sequenz(3)
# Ausgabe:
# 3
# 10
# 5
# 16
# 8
# 4
# 2
# 1

sequenz(145)
sequenz(46382633628526152)      # Länge von int-Werten ist in Python unbeschränkt


# von Rekursion zur Iteration, vgl. Bsp aus Kap. 5
def print_n(s, n):
    """ Gibt einen gegebenen String n-mal aus.

    s: String
    n: Anzahl an Ausgaben
    """
    while n > 0:    # noch mindestens einmal 
        print(s)
        n = n - 1   # Dekrement
    
print_n('Hallo', 5)
        


# warte auf eine bestimmte Nutzereingabe
while True:                 # ohne break ist das endlos!
    zeile = input('> ')
    if zeile == 'fertig':
        break               # Schleife sofort verlassen!
    print(zeile)
print('Endlich!')


# Newtons Methode zur Berechnung der Quadratwurzel
# https://de.wikipedia.org/wiki/Newtonverfahren#Berechnung_der_Quadratwurzel
a = 4               # wir wollen die Wurzel aus a >= 0 berechnen
x = 3               # das ist unsere erste Schätzung, darf nicht 0 sein
y = (x + a/x) / 2   # Newton sagt: mit dieser Formel wird es immer genauer!   
y                   # also ist das unsere neue Schätzung
# Ausgabe: 2.16666666667

# Nächste Iteration
x = y
y = (x + a/x) / 2
y                   # schon besser
# Ausgabe: 2.00641025641

# also nochmal
x = y
y = (x + a/x) / 2
y                   # nochmal besser
# Ausgabe: 2.0000102400...

# und ein letztes Mal
x = y
y = (x + a/x) / 2
y
# Ausgabe: 2.00000000002...     

# ziemlich gut, aber ist das genau genug für uns?
# numerische Ungenauigkeiten sind bei Typ float unvermeidbar

# Anzahl Iterationen sollte abhängig sein von der erzielten Verbesserung
# denn falls y = x ist x genau die Wurzel von a und wir sind fertig
epsilon = 0.00000001     # aber eine kleine Abweichung sei erlaubt
a = 4
x = 3
while True:
    print(x)
    y = (x + a / x) / 2
    if abs(y - x) < epsilon:  # Überprüfung, ob die Werte nahe genug sind
        break
    x = y

# Ausgabe:
# 3
# 2.1666666666666665
# 2.0064102564102564
# 2.0000102400262145
# 2.0000000000262146




