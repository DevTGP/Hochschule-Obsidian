"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


##  Textdateien lesen und schreiben
###############################################################################


# Öffnen einer Datei zum Schreiben ('w' für write)
# ! Falls Datei bereits existiert, werden enthaltene Daten gelöscht 
fout = open('ausgabe.txt', 'w') # liefert Dateiobjekt

# Datei ausgabe.txt in der IDE öffnen -> leer

# Schreiben von Daten in die Datei
zeile1 = 'Meine erste Textzeile für die Datei...\n'     # newline am Ende
len(zeile1)
fout.write(zeile1)          # Methode auf dem Dateiobjekt
# Ausgabe: 39 (Anzahl der geschriebenen Zeichen)

# ausgabe.txt noch leer 

zeile2 = 'Das ist schon die zweite Zeile für die Ausgabe.\n'
fout.write(zeile2)  # aktuelle Position wird gemerkt: nach der ersten Zeile
# Ausgabe: 48

# ausgabe.txt immer noch leer   -> Daten werden gepuffert

# Schließen der Datei nach dem Schreiben
fout.close()            # passiert sonst bei Programmende

# ausgabe.txt enthält beide Zeilen


# Verwenden von formatierten String-Literalen (f-Strings)
kamele = 42
f'Ich habe {kamele} Kamele gesehen.'
# Ausgabe: 'Ich habe 42 Kamele gesehen.'

# Einfügen der Werte von Ausdrücken in einen String
jahre = 3
fraction = 123.45       # float
f'In {jahre + 3} Jahren habe ich {fraction} Kamele gesehen'
# Ausgabe: 'In 6 Jahren habe ich 123.45 Kamele gesehen.'

x = 1
fout = open('ausgabe.txt', 'w')     # -> leer
fout.write(f'Meine {x}. Textzeile für die Datei...\n')
fout.write(f'Meine {x + 1}. Textzeile für die Datei...\n')
fout.close()

fin = open('ausgabe.txt')
fin.readline()
fin.readline()
fin.readline()
fin.readline()
fin.close()


# viele weitere Möglichkeiten der Formatierung:
# https://docs.python.org/3/tutorial/inputoutput.html

# Verwenden des Moduls os zum Abrufen des aktuellen Verzeichnisses
import os
cwd = os.getcwd()       # get current working directory
cwd
# Ausgabe: aktuelles Arbeitsverzeichnis 
# z.B. '/Users/schmitz/Python': absoluter Pfad beginnend mit /
# relative Pfade beginnen im cwd

# Einfaches Erstellen eines absoluten Pfads
abspath = os.path.abspath('memo.txt')
abspath
# Ausgabe: '/Users/schmitz/Python/memo.txt'

# Überprüfen, ob eine Datei im cwd existiert
exists = os.path.exists('ausgabe.txt')
exists
# Ausgabe: True

# Überprüfen, ob eine Datei ein Verzeichnis ist
isdir = os.path.isdir('ausgabe.txt')
isdir
# Ausgabe: False
isdir = os.path.isdir('/Users/schmitz')
isdir
# Ausgabe: True

# Auflisten des Inhalts eines Verzeichnisses
files = os.listdir(cwd)
files
# Ausgabe: ['musik', 'fotos', 'memo.txt']   (Liste aller Dateinamen inkl. Unterverz)

# Rekursives Durchlaufen eines Verzeichnisses
def durchlaufe(verz_name):
    for name in os.listdir(verz_name):      
        pfad = os.path.join(verz_name, name)    # Verz + Name = Pfad
        if os.path.isfile(pfad):
            print(pfad)
        else:
            durchlaufe(pfad)                    # wiederhole im Unterordner

durchlaufe(cwd)



##  Ausnahmen abfangen 
###############################################################################

# das sollte man schon beim Testen merken
try:
    x = 10 / 0      # man kanns ja mal probieren
except:
    print('Es ist etwas schiefgelaufen.')
    # ggf. hier reagieren und Problem beheben
print('Ohne Unterbrechung weitermachen')


# Fehler beim Öffnen einer nicht existierenden Datei abfangen
try:
    fin = open('nicht_da_datei')
except:
    print('Es ist etwas schiefgelaufen.')
# Ausgabe: 'Es ist etwas schiefgelaufen.'



##  Datenbank
###############################################################################

# Modul dbm stellt eine einfache Datenbank bereit
import dbm
db = dbm.open('bildunterschriften', 'c')    # liefert ein neues DB-Objekt

# - > siehe Dateiverzeichnis

# Hinzufügen von Einträgen zur Datenbank
db['cleese.png'] = 'Foto von John Cleese.'
db['cleese.png']
# Ausgabe: b'Foto von John Cleese'      # Präfix b: Datentyp Bytes

# Ersetzen eines Wertes in der Datenbank
db['cleese.png'] = 'Foto von John Cleese bei einem Silly Walk.'
db['cleese.png']
# Ausgabe: b'Foto von John Cleese bei einem Silly Walk.'

db['natur.png'] = 'Foto.'

# Durchlaufen der Datenbank und Ausgabe der Schlüssel und Werte
for schluessel in db.keys():
    print(schluessel, db[schluessel])
# Ausgabe: b'cleese.png' b'Foto von John Cleese bei einem Silly Walk.'
# Ausgabe: b'natur.png' b'Foto.'

# Schließen der Datenbank
db.close()

# -> siehe Datei: keine lesbare Textdatei

# Modul pickle zur (De)Serialisierung von Objekten
import pickle
t = [1, 2, 3]
s = pickle.dumps(t)     # Serialisierung
s
# Ausgabe: Byte-Strom, der Daten und Struktur von t repräsnetiert

t2 = pickle.loads(s)    # Deserialisierung: neues Objekt mit gleichen Werten
t2
# Ausgabe: [1, 2, 3]

# Listen haben gleiche Werte, sind aber unterschiedliche Objekte
print(t == t2)
# Ausgabe: True
print(t is t2)
# Ausgabe: False



##  Module schreiben und importieren
###############################################################################

import EiP_14_module    # wird ausgeführt inkl. Testcode 
# Ausgabe: 26           # unerwünscht








