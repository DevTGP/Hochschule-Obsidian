"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#

## Funktionsaufrufe
###############################################################################

# Aufruf einiger eingebauter Funktionen und Rückgabewert
type(42)        # liefert den Typ des Werts zurück, der als Argument angegeben ist
# Ausgabe: int, das ist der Rückgabewert

int('32')       # konvertiert das Argument in einen Wert vom Typ int
# Ausgabe: 32

int('Hello')    # Fehler weil Konvertierung nicht möglich
# ValueError: invalid literal for int(): Hello

int(3.99999)    # Dezimalstellen eines Arguments vom Typ float werden abgeschnitten 
# Ausgabe: 3

float(32)       # es geht auch umgekehrt von int nach float
# Ausgabe: 32.0

str(32)         # und nach str     
# Ausgabe: '32'

# in diesen Fällen gibt der Funktionsname den Typ den Rückgabewerts an



## Mathematische Funktionen und Komposition
###############################################################################

# dieser Funktionsname ist bisher unbekannt
sqrt(4)         # sqrt = square root
# Ausgabe NameError: name 'sqrt' is not defined

# Modul mit mathematischen Funktionen
import math
math

# der Aufruf erfolgt über die Punktschreibweise
#   damit werden Funktionen in einem importieren Modul angesprochen
math.sqrt(4)
# Ausgabe 2.0

# Beispiel https://de.wikipedia.org/wiki/Signal-Rausch-Verhältnis
verhaeltnis = 10    # Beispielwert für Signalleistung / Rauschleistung
dezibel = 10 * math.log10(verhaeltnis)
print(dezibel)
# Ausgabe: 10.0

# Logarithmen zu anderen Basen
math.log2(16)       # Basis 2
math.log(16)        # Basis e (natürlicher Logarithmus ln)

# math enthält auch wichtige Konstanten, jeweils bis zur zur Verfügung stehenden Genauigkeit
math.e
math.pi
math.log(math.e)

# weiteres Beispiel: sin() erwartet den Winkel im Bogenmaß (rad)
# https://de.wikipedia.org/wiki/Radiant_(Einheit)
radiant = 0.7
hoehe = math.sin(radiant)   
print(hoehe)
# Ausgabe: 0.644217687237691

# Konvertierung von Grad in Radiant
grad = 45
radiant = grad / 180.0 * math.pi    # für Umrechnung siehe Link oben
print(math.sin(radiant))            # Rückgabe in rad 
# Ausgabe: 0.707106781187

# Komposition: Ausdruck als Argument für den Aufruf einer Funktion
x = math.sin(grad / 180.0 * math.pi)    # -> Zwischenwert ohne Variablenname

# Reihenfolge:
# 1. Auswertung des Ausdrucks grad / 180.0 * math.pi
# 2. Aufruf von sin mit resultierendem Wert aus 1. als Argument

x = math.exp(math.log(x+1))

# Wenn man es einzeln ausschreibt, wird die Reihenfolge klar:
a = x + 1
b = math.log(a)
c = math.exp(b)
x = c



## Eigene Funktionen
###############################################################################

# Funktionsdefinition
def zeige_text():                           # Header, hier keine Argumente erwartet
    print('Veronika, der Lenz ist da.')     # Body
    print('Die Mädchen singen trallala.')   # Body

print(zeige_text)   # Funktionsobjekt im Speicher, siehe auch Variable Explorer

zeige_text()        # Funktionsaufruf, ohne Argumente
# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.

# Funktionen dürfen auch in anderen Deklarationen aufgerufen werden 
def wiederhole_refrain():
    zeige_text() 
    zeige_text()

wiederhole_refrain()
# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.
# Ausgabe: Veronika, der Lenz ist da.
# Ausgabe: Die Mädchen singen trallala.


# Definition versus Verwendung, siehe EiP_03_script.py



## Argumente und Parameter
###############################################################################

# Funktion mit einem Parameter: lokale Variable peter
def print_zweimal(peter):       # peter -> Wert des Arguments
    print(peter)
    print(peter)
    # print(concat)             # Demo Traceback


# Aufruf mit einem Werten
print_zweimal('Spam')           # peter -> 'Spam'
# Ausgabe: Spam
# Ausgabe: Spam

print_zweimal(17)               # peter -> 17
# Ausgabe: 17
# Ausgabe: 17

print_zweimal(math.pi)          # peter -> 3.1415...
# Ausgabe: 3.141592653589793
# Ausgabe: 3.141592653589793

# Verwendung von Ausdrücken als Argumente: wird nur einmal ausgewertet
print_zweimal('Spam ' * 4)      # peter -> 'Spam Spam Spam Spam '
# Ausgabe: Spam Spam Spam Spam
# Ausgabe: Spam Spam Spam Spam

print_zweimal(math.cos(math.pi))    # peter -> -1.0
# Ausgabe: -1.0
# Ausgabe: -1.0

# Aufruf mit Variable
michael = 'Eric, the half a bee.'
print_zweimal(michael)          # peter -> 'Eric, the half a bee.'
# Ausgabe: Eric, the half a bee.
# Ausgabe: Eric, the half a bee.

# lokale Variablen einer Funktion inkl. der Parameter sind außerhalb unbekannt
peter 
# Ausgabe: NameError
    
def zweimal_concat(teil1, teil2):
    concat = teil1 + teil2 
    print_zweimal(concat)

zeile1 = 'Bing tiddle '
zeile2 = 'tiddle bang.'
zweimal_concat(zeile1, zeile2)
# Ausgabe: Bing tiddle tiddle bang.
# Ausgabe: Bing tiddle tiddle bang.

# außerhalb der Ausführung der Funktion unbekannt
concat
# Ausgabe: NameError

# Demo Traceback


## Funktionen mit und ohne Rückgabewerte
###############################################################################

# ohne Rückgabewerte
ergebnis = print_zweimal('Bing')
# Ausgabe: Bing
# Ausgabe: Bing
print(ergebnis)             
# Ausgabe: None             # repräsentiert die Abwesenheit eines Wertes
print(type(None))           # None ist einziger Wert vom Typs NoneType
# Ausgabe: <class 'NoneType'>

# mit Rückgabewert
math.cos(radiant)           # Ausgabe des Ergebnisses im interaktive Modus
x = math.cos(radiant)       # keine Ausgabe, weil Wert in x 'aufgefangen' wird

math.sqrt(5)
(math.sqrt(5) + 1) / 2      # Rückgabewert wird in Ausdruck weiterverwendet
x = (math.sqrt(5) + 1) / 2  # x das Ergebnis des Ausdrucks zuordnen





