"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# auf MacOS ist die Ausführung ggf über die Konsole notwendig
#   (Problem beim Aufruf von Turtle aus einer IDE heraus)
#


import turtle           # Modul für einfache Grafiken
bob = turtle.Turtle()   # Schildkröte bob ist ein Zeichenstift in einem Fenster

# bob nimmt über die Punktschreibweise folgende Anweisungen entgegen (sog. Methoden):
#    fd(x):  x Pixel vorwärts (forward)   
#    bk(x):  x Pixel rückwärts (backward)   
#    lt(a):  drehe um a Grad nach links (left turn)   
#    rt(a):  drehe um a Grad nach rechts (right turn)
#    pu():   Stift hoch (pen up)   
#    pd():   Stift runter (pen down)

## Quadrat zeichnen
bob.fd(100)
bob.lt(90)
bob.fd(100)
bob.lt(90)
bob.fd(100)
bob.lt(90)
bob.fd(100)

# viel besser mit for-Anweisung
# for i in range(4):  # Header: wiederhole die eingerückten Anweisungen 4 mal
#     bob.fd(100)     # Body ist eingerückt
#     bob.lt(90)

# bob ist wieder in Ausgangsposition

turtle.mainloop()       # warte auf Eingaben (nur Fenster schließen möglich)



