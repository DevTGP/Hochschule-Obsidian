"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# auf MacOS ist die Ausführung ggf über die Konsole notwendig
#   (Problem beim Aufruf von Turtle aus einer IDE heraus)
#

import turtle           
bob = turtle.Turtle()   

# Weitere Generalisierung: beliebige Anzahl Ecken ermöglichen
#   -> Funktionsname anpassen: wir zeichnen nun ein regelmäßiges Polygon
def polygon(t, n, laenge):  # neuer Parameter n: Anzahl Ecken
    winkel = 360.0 / n      # ergibt sich aus n, da regelmäßig
    for i in range(n):      # bei n Ecken gibt es auch n Seiten  
        t.fd(laenge)
        t.lt(winkel)

# ein Quadrat ist ein spezielles Polygon, wobei n = 4 fest gewählt ist
# polygon(bob, 4, 100)

polygon(bob, 3, 2) 
polygon(bob, 4, 4)
polygon(bob, 5, 8)
polygon(bob, 6, 16)
polygon(bob, 7, 32)
polygon(bob, 8, 64)
polygon(bob, 9, 128)

# Schlüsselwort-Argumente tragen den Name der Parameter
polygon(bob, n = 10, laenge = 256)      # bessere Lesbarkeit!

turtle.mainloop()       # warte auf Eingaben (nur Fenster schließen möglich)



