"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

def zeilenzaehler(dateiname):
    zaehler = 0
    for zeile in open(dateiname):
        zaehler += 1
    return zaehler


print(zeilenzaehler('EiP_14_module.py'))    # nur zum Test: Selbstaufruf
# Ausgabe: 25


#if __name__ == '__main__':                  # False bei import   
#    print(zeilenzaehler('EiP_01.py'))
## Ausgabe: 111