"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# auf MacOS ist die Ausführung ggf über die Konsole notwendig
#   (Problem beim Aufruf von Turtle aus einer IDE heraus)
#

# Importe stehen nach Konvention immer am Anfang eines Skripts
import turtle
import math             # weil wir pi verwenden wollen


# # zeichnet Kreisnäherung mit Hilfe eines Polygons
# def kreis(t, r):                # r: Kreisradius
#     umfang = 2 * math.pi * r    # Umfang nach bekannter Formel
#     n = 50                      # Einschränkung: fest Anzahl Segmente
#     laenge = umfang / n         
#     polygon(t, n, laenge)

# Erweiterung der Schnittstelle um Anzahl der Segmente n ist nicht günstig:
#   großer Umfang -> erfordert viele Segmente
#   kleiner Umfang -> wenige Segmente genügen
# Umfang und n sind in etwa proportional
#   -> n kann daher passend innerhalb(!) der Funktion bestimmt werden
#   und zwar ohne die Schnittstelle unnötig zu verbreitern


# zeichnet Kreisnäherung mit Hilfe eines Polygons: gleiche Schnittstelle wie oben
def kreis(t, r):                
    umfang = 2 * math.pi * r    
    n = int(umfang / 3) + 1     # jedes Segment besteht aus ungefähr 3 Pixeln
    laenge = umfang / n         
    polygon(t, n, laenge)

# zeichet (unverändert) ein regelmäßiges Polygon 
def polygon(t, n, laenge):  
    winkel = 360.0 / n      # ergibt sich aus n, da regelmäßig
    for i in range(n):      # bei n Ecken gibt es auch n Seiten  
        t.fd(laenge)
        t.lt(winkel)

bob = turtle.Turtle()   # bob ist unser Zeichenstift

kreis(bob, 50)
kreis(bob, 150)


turtle.mainloop()       # warte auf Eingaben (nur Fenster schließen möglich)



