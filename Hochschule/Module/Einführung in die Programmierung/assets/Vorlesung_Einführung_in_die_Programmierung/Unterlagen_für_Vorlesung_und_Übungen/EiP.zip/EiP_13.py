"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""


#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


##  Datenstrukturen

## Übung 13-1: Datei einlesen, zerlegen, in Kleinbuchstaben umwandeln
## Übung 13-2: Wort-Histogramm für "Die Buddenbrooks"
###############################################################################

import string 

# Datei einlesen und zeilenweise verarbeiten
def verarbeite_datei(dateiname):
    """Erstellt ein Histogramm als dict mit den Wörtern aus einer Datei.

    dateiname: str
    """
    hist = dict()                       # Worthistogramm
    fp = open(dateiname)
    for zeile in fp:
        verarbeite_zeile(zeile, hist)   # hist wird verändert
    return hist

# Zeile zerlegen, aufbereiten und Ergebnis in das Worthistogramm eintragen
def verarbeite_zeile(zeile, hist):          # Anforderungen:
    """Fügt die Wörter einer Zeile zum Histogramm hinzu.

    Verändert hist.

    zeile: str
    hist: dict, Histogramm (Abbildung der Wörter auf ihre Frequenz)
    """
    zeile = zeile.replace('-', ' ')         # Bindestriche ersetzen
    for wort in zeile.split():              # für jedes Wort:
        wort = wort.strip(string.punctuation + string.whitespace)   # Sonderzeichen entfernen
        if wort != '':                                              # kommt vor
            wort = wort.lower()                                     # alles Kleinbuchstaben
            hist[wort] = hist.get(wort, 0) + 1                      # book-keeping

# Datei einlesen und Histogramm erstellen
hist = verarbeite_datei('buddenbrooks.txt')

# Anzahl aller Wörter
def summe_woerter(hist):
    """Liefert die Gesamtzahl der Häufigkeiten in einem Histogramm."""
    return sum(hist.values())       # dict-Methode liefert Liste aller Häufigkeiten

# Anzahl der unterschiedlichen Wörter
def unterschiedliche_woerter(hist):
    """Liefert die Anzahl der unterschiedlichen Wörter in einem Histogramm."""
    return len(hist)                # Anzahl Schlüssel-Wert-Paare

# Ausgaben
print('Gesamtzahl Wörter:', summe_woerter(hist))
# Ausgabe: Gesamtzahl Wörter: 228583

print('Anzahl der unterschiedlichen Wörter:', unterschiedliche_woerter(hist))
# Ausgabe: Anzahl der unterschiedlichen Wörter: 25053


## Übung 13-3: Die 20 häufigsten Wörter
###############################################################################

def haeufigste_woerter(hist):
    """Erstellt eine Liste der Schlüssel/Wert-Paare in einem Histogramm
    und sortiert sie anhand der Häufigkeit in absteigender Reihenfolge.

    hist: dict, Zuordnung der Wörter und deren Häufigkeit

    """
    t = []
    for schluessel, wert in hist.items():   # (Wort, Häufigkeit)
        t.append((wert, schluessel))        # Häufigkeit nach vorne für Sortierung
    t.sort(reverse=True)                    # absteigend
    return t

# Ausgabe der 20 häufigsten Wörter
t = haeufigste_woerter(hist)
print('Die 20 häufigsten Wörter lauten:')
for haeuf, wort in t[0:20]:
    print(wort, haeuf, sep='\t')
# Ausgabe:
# Die 20 häufigsten Wörter lauten:
# und	9582
# die	5716
# der	4906
# er	3720
# in	3376
# mit	3238
# zu	3215
# ...

# Fkt mit optionalem Parameter und Standardwert, falls Parameter nicht angegeben wird
def print_haeufigste_woerter(hist, anz=10):
    """Gibt die häufigsten Wörter in einem Histogramm und die entsprechenden
    Häufigkeiten aus.
    
    hist: dict, Histogramm (Zuordnung der Wörter und deren Häufigkeit)
    anz:  int, optionale Anzahl der Wörter, die ausgegeben werden sollen
    """
    t = haeufigste_woerter(hist)
    print('Die häufigsten', anz, 'Wörter sind:')
    for haeuf, wort in t[:anz]:
        print(wort, haeuf, sep='\t')

print_haeufigste_woerter(hist)

print_haeufigste_woerter(hist, 20)

print_haeufigste_woerter(hist, 50)


## Übung 13-4: Vergleich mit der Wortliste
###############################################################################

# Wörter aus dem Buch, die nicht in der Wortliste vorkommen
# Besonderheit: buddenbrooks ist durch Vorverarbeitung bereits ohne Umlaute und ohne ß
def subtrahiere(buch_hist, wortliste_hist):
    """Liefert ein Dictionary mit allen Wörtern, die in d1, aber nicht in d2 enthalten sind.

    d1, d2: dict
    """
    res = {}
    for schluessel in buch_hist:            # Wörter aus dem Buch
        ersetzt = schluessel.replace('ä', 'ae').replace('ü', 'ue').replace('ö', 'oe').replace('ß', 'ss')    # unnötig
        if ersetzt not in wortliste_hist:   
            res[schluessel] = None          # Wert im Ergebnisdict. egal
    return res

# Verarbeitung der Wortliste und Subtraktion
woerter = verarbeite_datei('wortliste.txt')
diff = subtrahiere(hist, woerter)


print('Anzahl Wörter im Buch:', len(hist))  
# Ausgabe: 25053
print('Anzahl Wörter in der Liste:', len(woerter))
# Ausgabe: 158927
print('Anzahl Wörter im Buch, die nicht in der Liste sind:', len(diff))
# Ausgabe: 11143
    
print("Folgende Wörter aus dem Buch sind nicht in der Wortliste enthalten:")
for wort in diff:
    print(wort, end=' ')
# Ausgabe: Wörter, die nicht in der Wortliste enthalten sind


## Zufallszahlen
###############################################################################

import random

# random() liefert zufällige float-Zahl aus dem Intervall [0,1)
for i in range(10):
    x = random.random()
    print(x)

# randint() liefert zufällige int-Zahl aus dem Intervall [low, high]
low, high = 5, 10
for i in range(10):
    x = random.randint(low, high)
    print(x)

# choice() wählt ein Element aus einer Sequenz mit je gleicher Wkt zufällig aus
t = [1, 2, 3]
for i in range(10):
    x = random.choice(t)
    print(x)

# Übung 13-5: (Pseudo-)Zufällige Auswahl eines Worts aus dem Histogramm
# dabei Interpretation der Häufigkeit als Wahrscheinlichkeit
import random

# Idee: Auswahl mit gleicher Wkt, aber Worte vervielfältigen
def zufalls_wort(h):
    """Wählt ein Wort zufällig aus einem Histogramm aus.

    Die Wahrscheinlichkeit jedes Wortes ist proportional zu seiner Häufigkeit.
    """
    t = []                          # ineffizient: wird bei jedem Aufruf neu erstellt
    for wort, haeuf in h.items():
        t.extend([wort] * haeuf)    # extend() erwartet Sequenz
    return random.choice(t)         # Gleichverteilung über Indexbereich von t

# Zufälliges Wort aus dem Histogramm auswählen
print(zufalls_wort(hist))
# Ausgabe: Ein zufälliges Wort basierend auf der Häufigkeit im Text


# Alternative: Preprocessing einmalig außerhalb der Funktion
t = []                          
for wort, haeuf in hist.items():
    t.extend([wort] * haeuf)

def zufalls_wort(t):
    return random.choice(t)

# Zufälliges Wort aus dem Histogramm auswählen
print(zufalls_wort(t))
print(zufalls_wort(t))
print(zufalls_wort(t))
print(zufalls_wort(t))


## Sets
###############################################################################
# https://docs.python.org/3/library/stdtypes.html#types-set

# Objekte vom Typ set sind endliche (!) Sammlungen ohne Ordnung und Duplikate
A = {1, 2, 3 ,4}
A
# Ausgabe: {1, 2, 3 ,4}
B = {2, 3, 2, 5}
B
# Ausgabe: {5, 2, 3}
L = {'011','101', 100}      # Elemente dürfen unerschiedlichen Typ haben
L
# Ausgabe:  {'011', 100, '101'}

E = set()      # leere Menge
# zur Erinnerung: F = {} legt ein leeres Dictionary an

2 in A              # Test auf Zugehoerigkeit  
# Ausgabe: True
1 in E
# Ausgabe: False
len(B)              #Anzahl Elementt
# Ausgabe: 3
len(E)
# Ausgabe: 0

for x in A:         # Mengen sind iterierbar
    print(x)

# Mengenoperationen: als Operator oder set-Methode
C = A | B       # Vereinigung
D = A.union(B)  # Alternative
C
# Ausgabe: {1, 2, 3, 4, 5}
C == D
# Ausgabe: True

C = A & B           # Durchschnitt
D = A.intersection(B)
C 
# Ausgabe: {2, 3}

C = A - B           # Mengendifferenz
D = A.difference(B)
C
# Ausgabe: {1, 4}

B <= A              # B Teilmenge von A
# Ausgabe: False
B.issubset(A)       # Alternative
# Ausgabe: False   
{1, 2} < A          # echte Teilmenge
# Ausgabe: True
L.isdisjoint(A)     # disjunkt?
# Ausgabe: True

d = {0 : 'a', 1 : 'b'}
D = set(d)          # Typumwandlung: Menge der Schlüssel
D
# Ausgabe: {0, 1}
    

# Mengen vom Typ set sind aenderbar
# Update-Operationen z.B.
A |= B      # Kurzform für A = A | B
A
# Ausgabe: {1, 2, 3, 4, 5} 
A.add(10)   
A.remove(2) 
A
# Ausgabe: {1, 3, 4, 5, 10}

t = [0, 1, 2, 3, 4, 5, 0]

# Bsp
def hat_duplikate(t):               # set(t) hat keine Duplikate
    return len(set(t)) < len(t)     # werden dadurch es weniger Elemente?

hat_duplikate(t)
# Ausgabe: True


# Elemente in Mengen müssen hashable sein:
#    ueber den Wert(!) des Elements wird eine Speicherstelle ermittelt
#    folglich sind aenderbare Typen nicht hashable
# insbesondere Mengen selbst sind NICHT hashable weil aenderbar
# d.h. Mengen von Mengen so nicht definierbar
P = {{1,2},{2,3}} 
# Ausgabe: TypeError: unhashable type: 'set'

# Typ frozenset ist immutable und hashable
P = {frozenset({1,2}),frozenset({2,3})}
P
# Ausgabe: {frozenset({2, 3}), frozenset({1, 2})}

# alles wie bei set
F = frozenset({1,2})
1 in F
# Ausgabe: True
# ausser: update nicht moeglich
F.add(3)
# Ausgabe: AttributeError: 'frozenset' object has no attribute 'add'


## Übung 13-6: subtrahiere-Fkt mit Standarddatentyp Set 

def subtrahiere(d1, d2):
    """Liefert ein Set aller Schlüssel, die in d1, aber nicht in d2 enthalten sind.

    d1, d2: dict
    """
    return set(d1) - set(d2)

#


# Behandlung in den Übungsstunden:

## Übung 13-7: Verbesserung von 13-5 mit kummulierten Häufigkeiten
###############################################################################
# 1. Verwenden Sie keys, um die Liste der Wörter im Buch zu erhalten. 
# 2. Erstellen Sie eine Liste, die die kumulative Summe der Worthäufigkeiten
#   enthält (siehe Übung 10-2). Das letzte Element in dieser Liste wäre die Summe
#   der Anzahl der Wörter im Buch, n.
# 3. Wählen Sie eine Zufallszahl zwischen 1 und n. Nutzen Sie eine Bisektionssuche
#   (siehe Übung 10-10), um den Index zu finden, an dem die Zufallszahl in
#   der kumulativen Summe eingesetzt werden soll.
# 4. Verwenden Sie diesen Index, um das entsprechende Wort in der Wortliste zu
#   finden.
#


## Übung 13-8: Markov-Analyse
###############################################################################





