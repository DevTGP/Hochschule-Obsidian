"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


## Wortliste in ein Dateiobjekt einlesen
###############################################################################

fin = open('wortliste.txt')     # fin steht für "file in"

fin.readline()          # lesen des Inhalts bis zum ersten Zeilenvorschub \n (Sonderzeichen)
# Ausgabe: 'Aale\n'
fin.readline()          # zweites Wort
# Ausgabe: 'Aalen\n'
fin.readline()          # drittes Wort: Lesestelle wird gemerkt
# Ausgabe: 'Aals\n'

for zeile in fin:           # jede Zeile lesen
    wort = zeile.strip()    # und ohne Sonderzeichen ausgeben 
    print(wort)

# for-Anweisung nochmal ausführen ergibt leere Ausgabe.... !? 

fin.seek(0)             
# Leseposition im Dateiobjekt zurück zum Anfang

# Anzahl Worte in der Datei zählen
zaehler = 0 
for zeile in fin: 
    zaehler = zaehler + 1
print(zaehler)
# Ausgabe: 159809




## Übung 9-1: Wörter mit mehr als 20 Zeichen ausgeben
###############################################################################

fin = open('wortliste.txt')
# zaehler = 0
for zeile in fin:
    wort = zeile.strip()
    if len(wort) > 20:
        # zaehler = zaehler + 1  
        print(wort)
# print(zaehler)
# Ausgabe: 2436


## Übung 9-2: Wörter ohne e
###############################################################################

def hat_kein_e(wort):       # Muster "Suche"
    """ Liefert True, falls wort kein e enthält, False sonst.

    wort: String
    """
    for zeichen in wort:
        if zeichen == 'e':
            return False    # Suche wird beim ersten e beendet
    return True             # hier kommen wir nur hin, wenn wort kein e enthält


hat_kein_e('absurd')
hat_kein_e('Kaffee')
hat_kein_e('Englisch')
hat_kein_e('')


# Wörter ohne 'e' ausgeben und den Prozentsatz berechnen
fin = open('wortliste.txt')
ohne_e = 0      # Zähler für Wörter ohne e
gesamt = 0      # Zählt alle Wörter
for zeile in fin:
    gesamt = gesamt + 1
    wort = zeile.strip()
    if hat_kein_e(wort):
        ohne_e = ohne_e + 1
        print(wort)

print('Anzahl Wörter:' , gesamt)
print('davon Wörter ohne "e":', ohne_e)
prozentsatz = ohne_e / gesamt * 100
print('Prozentsatz der Wörter ohne "e":' , prozentsatz, '%')
# Ausgabe: 5.7625...%




## Übung 9-3: Generalisierung
###############################################################################

def vermeiden(wort, verboten):
   """ Liefert True, falls wort keines der verbotenen Zeichen enthält.

   wort: String
   verboten: String
   """
   for zeichen in wort:
        if zeichen in verboten:
            return False
   return True

# Benutzer zur Eingabe eines Strings mit verbotenen Zeichen auffordern
verboten = input('Geben Sie die verbotenen Zeichen ein: ')

# Anzahl Wörter ohne verbotene Zeichen ermitteln
fin = open('wortliste.txt')
ohne_verboten = 0             
for zeile in fin:
    wort = zeile.strip()
    if vermeiden(wort, verboten):
        ohne_verboten = ohne_verboten + 1

print('Anzahl der Wörter ohne verbotene Zeichen:', ohne_verboten)

# Buchstaben mit der geringsten Häufigkeit in deutschen Texten (ohne Umlaute und ß):
# q x y j v p z k ...
# https://de.wikipedia.org/wiki/Buchstabenhäufigkeit

# qQxXY -> 157985



## Übung 9-4: alle Zeichen zulässig -> Suche erstes UNzulässige Zeichen
###############################################################################

def verwendet_nur(wort, zulaessig):
    """ Liefert True, falls wort nur aus zulässigen Zeichen besteht.

    wort: String
    zulaessig: String
    """
    for zeichen in wort:
        if zeichen not in zulaessig:    # unzulässiges Zeichen gefunden
            return False
    return True                             

# Beispiel für einen Satz, der nur aus bestimmten Zeichen besteht
satz = 'hello fellow'
print(verwendet_nur(satz, 'awefhlo '))
# Ausgabe: True



## Übung 9-5: alle erforderlichen Zeichen müssen verwendet werden
###############################################################################

def verwendet_alle(wort, erforderlich):
    """ Liefert True, falls in wort alle erforderlichen Zeichen vorkommen.

    wort: String
    erforderlich: String
    """
    for zeichen in erforderlich:    # alle erforderlichen Zeichen durchlaufen     
        if zeichen not in wort:     # mind. eins davon fehlt in wort
            return False            
    return True


# Wie viele Wörter verwenden alle Vokale aeiou?
fin = open('wortliste.txt')
vokale = 'aeiou'
zaehler = 0
for zeile in fin:
    wort = zeile.strip()
    if verwendet_alle(wort, vokale):
        zaehler = zaehler + 1
print('Anzahl der Wörter, die alle Vokale enthalten:', zaehler)
# Ausgabe: 1694


## Übung 9-6: Sind die Zeichen in einem Wort alphabetisch geordnet?
###############################################################################
# -> wir müssen je zwei(!) benachbarte Zeichen vergleichen

def ist_alphabetisch(wort):
    i = 0                           # von der Startposition  
    while i < len(wort)-1:          # bis zum vorletzten Zeichen    
        if wort[i] > wort[i+1]:     # Ordnung ist verletzt
            return False
        i = i + 1                   # nächste Position
    return True

# for-Schleife über Indexpositionen behandeln wir erst später

# Wie viele der Wörter sind alphabetisch geordnet?
fin = open('wortliste.txt')
zaehler = 0
for zeile in fin:
    wort = zeile.strip()
    if ist_alphabetisch(wort):
        zaehler = zaehler + 1
print('Anzahl der alphabetischen Wörter:', zaehler)
# Ausgabe: 630



# Alternative 1:  mit for-Schleife, aber ohne Index 
def ist_alphabetisch(wort):
    vorheriges = wort[0]    # wird in der ersten Iteration mit sich selbst verglichen
    for c in wort:
        if vorheriges > c:
            return False
        vorheriges = c      # aus aktuellem Zeichen wird in der nächsten Iteration das vorherige
    return True


# Alternative 2:  Rekursion
def ist_alphabetisch(wort):
    if len(wort) <= 1:                  # hier ist nichts mehr zu vergleichen
        return True
    if wort[0] > wort[1]:               # verleiche nur die ersten beiden Zeichen
            return False
    return ist_alphabetisch(wort[1:])   # Selbstauruf mit verkürztem Wort





## Reduktion eines Problems auf ein anderes
###############################################################################

# Alternative 
def verwendet_alle(wort, erforderlich):
    return verwendet_nur(erforderlich, wort)



# Funktion zum Testen von Palindromen: vorwärts und rückwärts gleich
def ist_palindrom(wort):
    i = 0               # Index li -> re
    j = len(wort) - 1   # Index re -> li
    while i < j:        # wir testen nur bis zur Mitte, warum?
        if wort[i] != wort[j]:
            return False
        i = i + 1
        j = j - 1
    return True


# Testfälle und Sollergebnisse
ist_palindrom('palindrom')                  
# Sollergebnis False
ist_palindrom('neveroddoreven')             
# Sollergebnis True
ist_palindrom('wasitacaroracatIsaw')        
# Sollergebnis False
ist_palindrom('')                       # Sonderfall
# Sollergebnis True
ist_palindrom('x')                      # Länge 1                      
# Sollergebnis True
ist_palindrom('ww')                     # Länge 2                         
# Sollergebnis True
ist_palindrom('wa')                        
# Sollergebnis False
ist_palindrom('waw')                    # Länge 3                         
# Sollergebnis True
ist_palindrom('wax')                        
# Sollergebnis False
ist_palindrom('abc')                        
# Sollergebnis False
ist_palindrom('aaa')                        
# Sollergebnis True
ist_palindrom('wawa')                   # Länge 4                           
# Sollergebnis False
ist_palindrom('waaw')                       
# Sollergebnis True
ist_palindrom('wasitacaroracatIsaw')    # lang      
# Sollergebnis False
ist_palindrom('ogeniederherrehredeinego')   
# Sollergebnis True


