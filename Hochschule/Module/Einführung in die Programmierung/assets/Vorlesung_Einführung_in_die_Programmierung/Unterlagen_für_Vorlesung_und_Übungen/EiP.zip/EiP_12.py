"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

#
# durch Tippen oder cut&paste im Py-Interpreter nachvollziehen!
#


##  Tupel anlegen, ändern und vegleichen
###############################################################################

# Erstellen eines Tupels
t = 'a', 'b', 'c', 'd', 'e'
t
# Ausgabe: ('a', 'b', 'c', 'd', 'e')

# Alternative Schreibweise mit Klammern ist üblich
t = ('a', 'b', 'c', 'd', 'e')
t
# Ausgabe: ('a', 'b', 'c', 'd', 'e')

# Erstellen eines leeren Tupels
t0 = tuple()
t0
# Ausgabe: ()

# Besonderheiten bei einelementigen Tupel
t1 = 'a',       # Komma notwendig
t1
# Ausgabe: ('a',)
type(t1)
# Ausgabe: <class 'tuple'>

t2 = ('a')  # das ist kein Tupel
t2
# Ausgabe: 'a'
type(t2)
# Ausgabe: <class 'str'>

# Umwandlung Sequenz -> tuple 
t = tuple('lupinen')    # ebenso für Listen
t
# Ausgabe: ('l', 'u', 'p', 'i', 'n', 'e', 'n')

# Zugriff auf Elemente mit Klammeroperator
# Indexbereich wie bei Strings und Listen
t = ('a', 'b', 'c', 'd', 'e')
t[0]
# Ausgabe: 'a'
t[5]
# Ausgabe: IndexError: tuple index out of range

# Slicing wie üblich
t[1:3]          # lesender Zugriff
# Ausgabe: ('b', 'c')

# Tupel sind unveränderbar!
t[0] = 'A'  
# Ausgabe: TypeError: 'tuple' object does not support item assignment

# Stattdessen wie bei String: Erstellen eines neuen Tupels
t_neu = ('A',) + t[1:]  # Hintereinanderschreibung mit + 
t_neu
# Ausgabe: ('A', 'b', 'c', 'd', 'e')
t is t_neu
# Ausgabe: False

# komponentenweiser Vergleich von links nach rechts
(0, 1, 2) < (0, 3, 4)   # weil 1 < 3
# Ausgabe: True
(0, 1) <= (0, 1)    
# Ausgabe: True



## Tupel-Zuweisungen, Rückgabewerte und Argumente
###############################################################################

1, 2, 3             # das ist ein Tupel
# Ausgabe: (1, 2, 3)

x, y, z = 1, 2, 3   # links und rechts steht EIN Tupel
x, y, z     
# Ausgabe: (1, 2, 3)

x, y, z = x + 1, y + 2, z + 3   # 1. rechte Seite auswerten 
x, y, z                         # 2. Zuweisung Tupel an Tupel
# Ausgabe: (4, 6, 8)


# üblicher Wertetausch mit temporärer Variablen
a, b = 1, 2
temp = a
a = b
b = temp
a, b
# Ausgabe: (2, 1)

a, b = 1, 2
a, b = b, a         # eleganter Wertetausch ohne temporäre Variable
a, b
# Ausgabe: (2, 1)

a, b = [1, 2]       # rechts ist jede Sequenz erlaubt
a, b = 1, 2, 3      # aber Anzahl Elemente muss gleich sein
# Ausgabe: ValueError: too many values to unpack (expected 2)

# Bsp: Aufteilen einer E-Mail-Adresse in Benutzername und Domain
adr = 'monty@python.org'
uname, domain = adr.split('@')  # rechts zwei Strings
uname
# Ausgabe: 'monty'
domain
# Ausgabe: 'python.org'

# Bsp: ganzzahlige Division und Rest
t = divmod(7, 3)    # eingebaute Funktion erwartet und liefert zwei Werte
t
# Ausgabe: (2, 1)
quot, rest = divmod(7, 3) # unpacking durch Tupel-Zuweisung
quot
# Ausgabe: 2
rest
# Ausgabe: 1

# Bsp: min und max
def min_max(t):
    return min(t), max(t)   # eingebaute Funktionen für Sequenzen    

min_max([1, 2, 3, 4, 5])    # liefert ein Tupel mit zwei Komponenten
# Ausgabe: (1, 5)

# Variable Anzahl Argumente 
def printalles(*args):      # *-Operator sammelt die aktuellen Parameter in einem Tupel
    print(args)

printalles(1, 2.0, '3')
# Ausgabe: (1, 2.0, '3')

printalles(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
# Ausgabe: (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Umgekehrt: *-Operator als Streuung
t = (7, 3)
divmod(t)       
# Ausgabe: TypeError: divmod expected 2 arguments, got 1
t = (7, 3)
divmod(*t)
# Ausgabe: (2, 1)
*t          # aber nur an bestimmten Stellen möglich
# Ausgabe: SyntaxError: can't use starred expression here

max(1, 2, 3)    # Implementierung von max() verwendet *args
sum(1, 2, 3)    # sum() dagegen nicht
# Ausgabe: TypeError: sum() takes at most 2 arguments (3 given) 
sum((1,2,3))    # vorher zu einem Argument verpacken    
# Ausgabe: 6




## Kombination von Listen, Tupeln und Dictionaries 
###############################################################################

# Kombination von Sequenzen mit zip() 
s = 'abc'
t = [0, 1, 2]
zip(s, t)       # ordnet korrespondierende Elemente einander zu
# Ausgabe: <zip object at 0x169175a80>

for pair in zip(s, t):  # mit for über den Iterator
    print(pair)         # Elemente sind 2er-Tupel
# Ausgabe:
# ('a', 0)
# ('b', 1)
# ('c', 2)

my_iterator = zip(s,t)
my_iterator[1]      # kein Indexzugriff möglich
# Ausgabe: TypeError: 'zip' object is not subscriptable

# aber wir können uns behelfen, falls notwendig:
my_list = list(zip(s, t))     # Iterator -> Liste
my_list
# Ausgabe: [('a', 0), ('b', 1), ('c', 2)]
my_list[1]
# Ausgabe: ('b', 1)

# die kürzere Sequenz ist maßgeblich
list(zip('Eber', 'Alb'))
# Ausgabe: [('E', 'A'), ('b', 'l'), ('e', 'b')]

# unpacking bereits in der for-Anweisung möglich
t = [('a', 0), ('b', 1), ('c', 2)]
for zeichen, zahl in t:     # Tupel-Zuweisung
    print(zahl, zeichen)
# Ausgabe:
# 0 a
# 1 b
# 2 c

# Bsp: Prüfen auf Übereinstimmungen zwischen zwei Sequenzen
def hat_treffer(t1, t2):
    for x, y in zip(t1, t2):
        if x == y:
            return True
    return False

hat_treffer('abc', 'adc')
# Ausgabe: True     # wegen 'a'
hat_treffer([1, 2, 3, 0, 4], (4, 3, 2, 0, 1))
# Ausgabe: True     # wegen 0

# Einführung eines zusätzlichen Index auf einer Sequenz
for index, element in enumerate('abc'):     # eingebaute Funktion
    print(index, element)
# Ausgabe:
# 0 a
# 1 b
# 2 c

# Verwenden von Dictionaries mit Tupeln
d = {'a': 0, 'b': 1, 'c': 2}
for key in d:       # Wdh: Iteration über dict liefert nur den Key
    print(key)
# Ausgabe:
# a
# b
# c

# dict-Methode items() liefert Iterator über Schlüssel-Wert-Tupel
for key, value in d.items():
    print(key, value)
# Ausgabe:
# a 0
# b 1
# c 2

# Erstellen eines Dictionaries aus einer Liste von Tupeln
t = [('a', 0), ('c', 2), ('b', 1)]
d = dict(t)
d
# Ausgabe: {'a': 0, 'c': 2, 'b': 1}

# Verwenden von zip zum Erstellen eines Dictionaries
d = dict(zip('abc', range(3)))
d
# Ausgabe: {'a': 0, 'b': 1, 'c': 2}

# Bsp: Telefonverzeichnis als Dictionary mit Tupel-Schlüssel
verzeichnis = {}
eintrag = ('Cleese', 'John')
verzeichnis[eintrag] = '08700 100 222'
verzeichnis
# Ausgabe: {('Cleese', 'John'): '08700 100 222'}

# Liste mit Schlüssel-Wert-Tupeln
eintraege = [(('Chapman', 'Graham'),    '08700 100 223'), 
             (('Idle', 'Eric'),         '08700 100 224'),
             (('Gilliam', 'Terry'),     '08700 100 225'),
             (('Jones', 'Terry'),       '08700 100 226'),
             (('Palin', 'Michael'),     '08700 100 227')
            ]
verzeichnis.update(eintraege)
verzeichnis               

for nachname, vorname in verzeichnis:
    print(vorname, nachname, verzeichnis[nachname, vorname])



