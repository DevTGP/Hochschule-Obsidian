"""This module contains a code example related to

Think Python, 2nd Edition
by Allen Downey
http://thinkpython2.com

Copyright 2016 Allen Downey

License: http://creativecommons.org/licenses/by/4.0/
"""

# 
# als Script ausführen
#

n = 71

# Ausdruck wird im Skriptmodus nicht ausgegeben, es sei denn, er wird explizit ausgegeben:
n + 25
# Ausgabe: keine

# Einfache mathematische Operationen
meilen = 26.2
meilen * 1.61
# Ausgabe: keine

# im Unterschied zu 
print(meilen * 1.61)

